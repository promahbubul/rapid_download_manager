# Role Permission Matrix

Legend: C = Create, R = Read, U = Update, D = Delete, A = Approve, — = No access.

Platform-level roles (`PLATFORM_OWNER`, `PLATFORM_SUPPORT`) are proposed additions (see [`../business/open-questions.md`](open-questions.md)); they do not exist in the schema yet. `tenantId = null` for both.

| Module | Platform Owner | Platform Support | Tenant Admin | Manager | Finance | Support | Advertiser | Affiliate |
|---|---|---|---|---|---|---|---|---|
| Tenants (all) | CRUD+A | R | — | — | — | — | — | — |
| Own Tenant settings | — | — | CRUD | R | R | R | — | — |
| Users (own tenant) | R (read-only, support) | R | CRUD | R | — | R | — | — |
| Advertisers | — | R | CRUD+A | R,U | R | R | R (own) | — |
| Affiliates | — | R | CRUD+A | R,U | R | R | — | R (own) |
| Offers | — | R | CRUD | R,U | — | R | R (own, request only) | R (assigned) |
| Campaigns | — | — | CRUD | CRUD | — | R | — | CRUD (own) |
| Tracking Links | — | — | R | R | — | — | — | CRUD (own) |
| Clicks (raw) | — | — | R | R | — | — | R (own offers) | R (own) |
| Conversions | — | — | R,U (dispute) | R | R | R | R (own) | R (own) |
| Fraud Events | — | R | R,U | R | — | — | — | — |
| Payouts | — | — | A | A (assigned affiliates) | CRUD+A | R | — | C (request), R (own) |
| Invoices / Billing | R | R | R | — | R,U | — | R (own) | — |
| Subscription Plan | CRUD | R | R (own) | — | R (own) | — | — | — |
| Reports | R (all tenants, aggregate) | R (aggregate) | R (own tenant) | R (assigned) | R (financial) | — | R (own) | R (own) |
| Webhooks / API Keys | — | — | CRUD | — | — | — | R (own) | — |
| Audit Logs | R (all) | R (all) | R (own tenant) | — | — | — | — | — |
| Notifications | send (all) | send (support) | send (own tenant) | send (assigned) | — | send | receive | receive |

**Note**: this matrix does not yet exist as enforced code — see [`../security/security-architecture.md`](../security/security-architecture.md) for the current gap (no `RolesGuard` exists at all today) and [`../analysis/target-state.md`](../analysis/target-state.md) for the remediation plan.
