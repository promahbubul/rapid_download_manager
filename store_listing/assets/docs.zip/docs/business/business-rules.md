# Business Rules

Each rule is explicit and testable. Rules marked **(not yet enforced)** describe intended behavior not currently implemented in code — see [`../analysis/current-state.md`](../analysis/current-state.md).

| ID | Rule |
|---|---|
| BR-001 | A `User` belongs to at most one `Tenant`. `tenantId = null` is reserved for platform-level staff only, never for a tenant-scoped role. |
| BR-002 | Every query against tenant-owned data MUST filter by `tenantId`, except for platform-level roles acting in an explicit cross-tenant context. **(not yet enforced — no tenant guard exists today)** |
| BR-003 | `Click.clickId` is unique platform-wide (already a DB unique constraint). |
| BR-004 | A `Conversion` is uniquely identified by `(tenantId, advertiserId, transactionId)`. A postback repeating an existing triple must be rejected as a duplicate, not recorded again. |
| BR-005 | `Conversion.revenue`/`payout`/`profit` are always computed server-side from the referenced `Offer` at conversion time. A postback caller can never dictate these amounts. **(contradicted by one legacy doc — see ADR-002)** |
| BR-006 | A postback request must present a valid secret/signature tied to the specific `Advertiser.postbackSecretHash`. Requests without a valid credential are rejected before any data is read. **(not yet implemented — postback endpoint does not exist)** |
| BR-007 | Only an `Affiliate` with `status = approved` may generate a billable click through their tracking link. `pending`, `suspended`, and `rejected` affiliates cannot. |
| BR-008 | A click that would exceed `Offer.dailyCap` or `Offer.monthlyCap` is redirected to `Offer.fallbackUrl` (if set) and recorded with `ClickStatus.filtered`, not `accepted`. |
| BR-009 | `Payout.status` transitions only forward: `requested → approved → processing → paid`, with `rejected`/`failed`/`cancelled` reachable from any pre-`paid` state. No backward transition is valid. |
| BR-010 | A `FraudEvent.score` of 71–100 automatically sets the associated `Click`/`Conversion` to a blocked/fraud state. A score of 31–70 flags the record for manual review without auto-blocking. A score of 0–30 requires no action. |
| BR-011 | All monetary values are stored as `Decimal(18,6)`. Floating-point representation of money is prohibited anywhere in the codebase. |
| BR-012 | Any mutating action taken by a platform-level or tenant-admin role against another user's or tenant's data must produce an `AuditLog` entry. **(not yet enforced — no module writes to `AuditLog` yet)** |
| BR-013 | A `UserRole` value determines default permissions (see [role-permission-matrix.md](role-permission-matrix.md)); a `User.tenantId` being `null` vs. set determines whether that role is interpreted as platform-scoped or tenant-scoped. |
| BR-014 | Usage against a `SubscriptionPlan`'s limits (`maxClicks`, `maxConversions`, `maxAffiliates`, `maxAdvertisers`, `maxOffers`) is tracked via `UsageCounter`. Exceeding a hard limit blocks further consumption of that resource until the period resets or the plan is upgraded. **(not yet implemented — no enforcement code exists)** |
| BR-015 | An `Offer`'s `revenue` should be ≥ `payout` under normal operation (platform/tenant should not operate at a loss per conversion by default); an offer where `payout > revenue` requires explicit acknowledgment at creation time. **(assumption — no current validation enforces this; flagged in Open Questions)** |
| BR-016 | Attribution is single-touch, last-click, keyed by `clickId`. A conversion referencing a `clickId` outside its offer's attribution window (proposed field, not yet in schema) is rejected as "click not found," not attributed to a different click. |
