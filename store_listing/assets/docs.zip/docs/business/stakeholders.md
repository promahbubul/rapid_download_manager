# Stakeholders

| Stakeholder | Type | Interest |
|---|---|---|
| Platform Owner | Internal (TrakAff company) | Overall business success, subscription revenue, tenant retention |
| Platform Support staff | Internal | Resolving cross-tenant support issues without full ownership access |
| Tenant Admin (`SUPER_ADMIN`/proposed `TENANT_ADMIN`) | External, paying customer | Running their own affiliate program successfully |
| Tenant Manager (`MANAGER`) | External, tenant's staff | Day-to-day affiliate/advertiser relationship management |
| Tenant Finance (`FINANCE`) | External, tenant's staff | Accurate payout approval, financial reconciliation |
| Tenant Support (`SUPPORT`) | External, tenant's staff | Handling affiliate/advertiser tickets without financial access |
| Advertiser | External, tenant's customer | Getting real, non-fraudulent conversions at agreed cost |
| Affiliate / Publisher | External, tenant's partner | Accurate tracking, timely payout, fair fraud judgment |
| End Visitor | Not a system user | Fast redirect, no degraded experience from tracking overhead |
| External Advertiser Server | System integration | Reliable postback delivery/retry, clear success/failure response |
| Payment Processor (Stripe / PayPal / Wise) | Third-party integration | Webhook reliability, correct amounts, idempotent requests |

No stakeholder list exists in any prior planning document — this is the first time actors have been enumerated against their actual interest rather than just their permissions.
