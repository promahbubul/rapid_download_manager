# Open Questions

Questions that materially affect architecture, database design, business rules, security, or scalability, and cannot be answered from the existing 24 legacy planning documents or the codebase. Nothing below has been silently decided.

1. **Target market / vertical** — is TrakAff horizontal (any performance-marketing niche) or focused on a specific vertical (finance, gaming, e-commerce, etc.)? No document or dashboard specifies one.
2. **Platform-level operator persona** — is a dedicated 5th dashboard for `PLATFORM_OWNER`/`PLATFORM_SUPPORT` an MVP requirement, or deferred to V2? No current dashboard serves this persona at all.
3. **Frontend brand unification** — `tracking-super-admin-dashboard` is branded "Dicetrack"; the other three dashboards are branded "AffiliatePro." Is this intentional per-audience branding, or should it be unified under one name?
4. **Final pricing** — two different four-tier pricing tables exist in legacy docs with different dollar figures (Starter $49–99, Growth $149–299, Pro/Business $299–699, Enterprise Custom). Neither has been confirmed as final.
5. **Payment providers** — Stripe (subscriptions) and PayPal/Wise (affiliate payouts) are assumed throughout legacy docs but never explicitly confirmed as committed vendor choices.
6. **Data retention policy** — how long should raw `Click` rows (containing IP address, user agent, referrer) be retained? Not addressed anywhere.
7. **Compliance requirements** — does the platform need GDPR/CCPA compliance given it stores `Click.ipAddress`/`userAgent`? No document addresses this.
8. **Multi-region deployment** — deferred by every legacy document, but no target date or trigger condition (e.g. "when we have a customer in region X") is defined.
9. **Cloud provider** — Cloudflare is assumed for DNS/edge/WAF, but no compute/hosting provider (AWS, GCP, DigitalOcean, Hetzner) is committed.
10. **Self-hosted availability** — should a self-hosted deployment option (like Binom offers) ever be built, or is this SaaS-only permanently?
11. **White-label strategy scope** — deferred to Enterprise scope, but not scoped in any detail (custom domain only? custom branding? custom email sender?).
12. **Fraud policy ownership** — the additive scoring bands (VPN +40, Bot +30, etc.) are a reasonable starting point copied from legacy docs, not a validated business policy. Who owns tuning these thresholds against real traffic once it exists?
13. **`LedgerEntry` migration timing** — introducing an immutable ledger (see ADR-006) changes how `Affiliate.balance` is computed. This requires sign-off before implementation since it touches money-handling code paths.
14. **`Offer.revenue >= Offer.payout` enforcement** — should this be a hard DB constraint, an application-level warning, or left unenforced (BR-015)?
15. **Attribution window default** — proposed default of 30 days (`Offer.attributionWindowDays`) is a placeholder recommendation, not a validated business decision.

Anything not listed here that a future task discovers to be undecided should be added to this file, not silently resolved.
