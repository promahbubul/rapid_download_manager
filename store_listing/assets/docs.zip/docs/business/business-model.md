# Business Model

## Who Pays, Who Earns, What Is Sold

TrakAff sells **performance-marketing tracking infrastructure as a service**, not traffic and not products. Two coexisting revenue models are supported by the current design; Model A is primary.

### Model A — SaaS Subscription (primary)

- **Who pays**: A client company ("Tenant") pays TrakAff a recurring subscription fee to operate its own affiliate/partner program on the platform.
- **Who earns**: TrakAff earns the subscription fee. The Tenant separately earns/pays whatever it negotiates with its own Advertisers and Affiliates — TrakAff is not a party to that money flow.
- **What's being sold**: tracking, attribution, fraud signal, commission calculation, and reporting tooling, metered by usage (clicks, conversions, affiliates, advertisers, offers, API requests, storage — see `UsageCounter`).
- **Money flow**: Tenant → TrakAff (subscription, via Stripe) · Tenant's own Advertiser → Tenant's own Affiliate (commission, outside TrakAff's ledger unless Model B is also active for that tenant).

### Model B — Affiliate Network Margin (secondary, supported, not primary)

- **Who pays**: The Advertiser pays into the platform per conversion (`Offer.revenue`).
- **Who earns**: The Affiliate earns `Offer.payout` per conversion; the platform (or the Tenant operating as a network) keeps `profit = revenue − payout`.
- This model requires no schema changes — `Offer.revenue`/`Offer.payout`/computed `Conversion.profit` already support it.

## Revenue Sources

1. Subscription fees (`SubscriptionPlan.priceMonthly` / `priceYearly`) — primary, Day 1.
2. Usage overage fees (beyond `SubscriptionPlan.maxClicks` etc.) — V1, requires billing logic not yet built.
3. Network margin per conversion (Model B) — available if a tenant chooses this mode; no separate billing plumbing needed beyond what exists.
4. Not pursued at this stage: flat transaction fees, enterprise custom contracts, professional services — no current demand signal, each adds real operational surface.

## Cost Centers

- Infrastructure (Postgres, later Redis/ClickHouse hosting).
- Payment processing fees (Stripe for subscriptions, PayPal/Wise for affiliate payouts; Payoneer/RazorPay/Webmoney planned as additional options — see FR-033).
- Third-party fraud/GeoIP data (IPQualityScore, Fingerprint, MaxMind) — V2, usage-based cost.
- Support staff time (Platform-level `PLATFORM_SUPPORT` role).

## Commission / Fee Model

- Per-conversion: `profit = revenue − payout`, both `Decimal(18,6)`, computed server-side from the `Offer` record at conversion time — never trusted from an inbound postback payload (see BR-006).
- No precedence/tiered commission rule engine in MVP (see ADR and Target State) — flat per-offer rate only, until a real tenant requests otherwise.
