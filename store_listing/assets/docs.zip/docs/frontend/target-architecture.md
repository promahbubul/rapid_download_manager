# Target Frontend Architecture

**Status: proposal only. Nothing in this document has been implemented.** Per the audit mandate, this is Phase 4 of the process (identify exact changes) and Phase 5 (group by risk) — implementation begins only after explicit approval, feature by feature.

Guiding principle for everything below: **Improve → Extract → Reuse → Standardize → Refactor, never Delete → Rewrite Everything.** No app is proposed for a full rewrite. Backend logic, API contracts, and business rules are untouched by every item below.

---

## What NOT to do (stated up front, because the source prompt's own example structures invite over-reach)

- **Do not migrate to a `features/` folder rewrite.** The current technical-type-at-top/feature-based-one-level-in structure is adequate (folder-structure.md) and a full migration would touch every file in 5 apps for a maintainability gain that a lighter-weight fix (§folder-structure.md's additive recommendations) already captures.
- **Do not build one mega-`DataTable` component with dozens of props.** Extract `Pagination`, `FilterBar`, and `TableToolbar` as three small, separately-usable pieces (frontend-rules.md rule 2).
- **Do not introduce a global state library.** No finding in this audit calls for one; all state is legitimately page-local today.
- **Do not build an API/service layer speculatively.** No backend exists yet to call (docs/analysis/current-state.md). Introducing hooks now, before Phase 7 wiring, is about *shape* (one call site per resource instead of scattered direct imports), not about building real data-fetching infrastructure early.

---

## Target state, by area

### 1. Shared package (highest-leverage, longest-horizon change)

Introduce a real shared package for the `components/ui/` primitives, `lib/chart-colors.ts`, `lib/nav-active.ts`, and the `form/` field-wrapper set — the exact set of files already conceptually shared but currently copy-pasted (current-architecture.md §1, §6). Use npm workspaces (all 5 apps already use npm/`package-lock.json` — no reason to introduce pnpm/yarn solely for this) with a `packages/ui` package.

This is explicitly **not** proposed as an immediate change — it requires initializing a monorepo root, migrating 5 independent git histories or accepting a fresh start, and updating every app's imports. It's the correct end state, but it's the highest-risk item in this document (see Risk Grouping) and should be scheduled deliberately, likely alongside — not before — the Phase 7 backend-wiring work already planned in the roadmap, since that work will touch every app's data layer anyway.

### 2. Pagination & filtering — one hook, used everywhere, doing what PL already does correctly

Extract `usePaginatedList<T>(rows: T[], { pageSize, filterFn })` returning `{ pageRows, currentPage, totalPages, setPage, filtered }`. Reference implementation: `tracking-platform-dashboard`'s `tenants-list.tsx` logic, which is the only one of 15+ near-duplicate implementations across the workspace that's actually correct (real filter, real slice, resets to page 1 on filter change, matching empty state). Land this in each app first as a local `src/hooks/use-paginated-list.ts` (frontend-rules.md rule 4's "shape before infrastructure" principle) — do not wait for the shared package in §1.

**This simultaneously fixes**: the decorative-pagination problem (SA's worst offender, 20+ call sites), the "filters that don't filter" problem (AF/AD/UD), and gives every list a real, reachable empty state for free (fixing current-architecture.md §8 as a side effect rather than a separate effort).

### 3. Create UX — one rule, applied consistently

**Rule**: ≤7 meaningful fields and no multi-step/file-heavy workflow → Dialog. 8+ fields, genuine multi-step, or heavy file/relationship management → full page. Apply this to fix the specific violations found:

- SA: remove the fake stepper (`activeStep` hardcoded to 1) from advertiser/affiliate/manager add-forms — either wire it to real step state or remove the stepper chrome entirely and keep the single-page form it already functionally is. Convert the 5 inline "permanently visible mini-form" settings sections (faqs, offer-category, offer-traffic-type, signup-question, tracking-domains) to a Dialog opened by an explicit "Add" button, consistent with every other create flow.
- SA: support-ticket add-form (4 fields) is the one over-scoped-for-its-size full page in the workspace — convert to Dialog.
- AF: wire the 2 dead "Add Payment Method"/"Add Postback"/"Add Event" buttons to actual Dialogs, or if the underlying feature isn't ready to be interactive yet, visually mark them as disabled/coming-soon rather than rendering a clickable-looking button with no handler (frontend-rules.md rule 15).
- AF: rebuild `edit-profile-modal.tsx` on the shared `form/` package (fixes both the missing-validation gap and the accessibility gap in one change, since it's the same root cause).
- UD: replace the `<ComingSoon />` stub on Add Offer with a real form once the offer-creation requirements are ready to build (this is a content gap, not strictly a UX-pattern gap — flagged here since it's the one place the pattern is "nothing" rather than "wrong").
- PL: no change required — already follows the rule.

### 4. Design tokens — eliminate raw hex in shared primitives first, then opportunistically elsewhere

Priority order: (a) `components/ui/checkbox.tsx`, `switch.tsx`, `toggle-group.tsx`, `image-dropzone.tsx`, `rich-text-editor.tsx` — these are shared-by-copy across 4-5 apps, so fixing the hex-to-token bypass here has the widest effect for the least effort; (b) `performance-chart.tsx` and other chart components hardcoding series colors instead of `CHART_SLOT_VAR`; (c) everything else, fixed opportunistically per frontend-rules.md rule 16. Also fix the two concrete cross-app bugs: add the missing `--chart-1..8` tokens to `tracking-advertiser-dashboard`'s `globals.css` (currently silently absent), and reconcile `tracking-user-dashboard`'s hex-encoded brand colors + extra `--brand-gradient` variable against the other 4 apps' `oklch()` encoding (decide: adopt UD's approach everywhere, since it's simpler and already has a working `brand` button variant, or convert UD to match the other 4 — this is a design decision, not purely technical, see Open Questions below).

### 5. Component placement cleanup

Move `affiliates-pagination.tsx` and `affiliate-stepper.tsx` (SA) out of `components/affiliates/` — pagination becomes `components/ui/pagination.tsx` (matching what PL and AD already do correctly), stepper either gets fixed per §3 and moves to `components/shared/` or is removed. Purely mechanical, zero behavior change beyond the stepper fix already covered in §3.

### 6. Accessibility fixes

- AF's `edit-profile-modal.tsx`: covered by §3 (rebuilding on the shared `form/` package fixes the `htmlFor`/`id` association gap as a side effect).
- Add `DialogDescription` to AD's `edit-profile-dialog.tsx` (currently a plain `<p>`) and UD's `AffiliateDetailsModal` (currently missing entirely).
- Add a visible or `aria-label`ed label to filter-bar `Select`s workspace-wide — this can land as part of the `FilterBar` extraction in §7 rather than as a separate pass across dozens of existing call sites.

### 7. Shared Components layer

Extract `FilterBar`, `TableToolbar`, and (lower priority, needs a pairwise diff first per frontend-rules.md rule 13) `DetailsModal` and `EmptyState` — see component-reuse-map.md for the full reasoning per component. Land these per-app initially (not blocked on §1's shared package), since the immediate win is de-duplication within each app; promoting them into a cross-app package happens naturally once §1 is scheduled.

---

## Migration path (current → target), safely

1. Land `usePaginatedList` (§2) in one app first — recommend `tracking-affiliate-dashboard`, since it has the least existing pagination code to conflict with and the clearest current dysfunction (filters that visibly do nothing).
2. Once validated there, apply the same hook shape to SA (highest call-site count, highest payoff) and AD/UD.
3. Design-token fixes (§4) can happen in parallel at any time — they're isolated, low-risk, file-local changes.
4. Create-UX fixes (§3) can happen in parallel, per-app, at any time — each one is isolated to a single form/component.
5. Component placement cleanup (§5) happens alongside whichever of §2/§3 touches those specific files.
6. Shared Components extraction (§7) happens after §2 proves the pattern works in at least 2 apps, so the extracted `FilterBar`/`TableToolbar` API is validated against real variation, not designed speculatively.
7. Shared package (§1) is scheduled last and separately, ideally coordinated with the Phase 7 backend-wiring work already on the roadmap.

---

## Proposed Changes — Grouped by Risk

### Safe (isolated, mechanical, no behavior change to correct functionality — i.e., only fixes things that are already broken/decorative)
- Fix raw-hex-in-shared-primitives (§4a): `checkbox.tsx`, `switch.tsx`, `toggle-group.tsx`, `image-dropzone.tsx`, `rich-text-editor.tsx` across the apps that share them.
- Add missing `--chart-1..8` tokens to AD's `globals.css`.
- Move `affiliates-pagination.tsx` to `components/ui/pagination.tsx` in SA (import-path change only, no logic change).
- Add `DialogDescription` to AD's and UD's identified Dialogs.
- Visually disable (or remove) AF's 2 dead "Add" buttons rather than leaving them clickable-looking with no handler.

### Moderate (behavior changes, but scoped to one component/feature at a time, independently testable)
- Extract and land `usePaginatedList` per app (§2), starting with AF.
- Rebuild AF's `edit-profile-modal.tsx` on the shared `form/` package (§3, §6).
- Convert SA's 5 inline mini-add-forms to Dialogs; convert SA's support-ticket add-form to a Dialog (§3).
- Remove or properly wire SA's 3 fake steppers (§3).
- Extract `FilterBar` and `TableToolbar` shared components per app (§7).
- Reconcile UD's brand-color encoding against the other 4 apps (§4) — **this one has an open design question below and shouldn't proceed without a decision.**

### High-risk (broad blast radius, touches every app, needs dedicated scheduling)
- Real shared package / monorepo (`packages/ui`) (§1) — touches every app's import paths and build config; should not be started opportunistically alongside other work.
- Any decision to unify the 5 apps' visual identity/brand tokens into one canonical set (currently 4-of-5 agree, UD diverges) — this is as much a product/brand decision as a technical one.

---

## Open questions this audit surfaces (not architecture decisions I can make unilaterally)

1. Should `tracking-user-dashboard`'s brand-color encoding (hex + `--brand-gradient` variable, its own button variant) become the standard the other 4 apps adopt, or should UD be converted to match SA/PL/AF/AD's `oklch()` approach? Both are currently visually intending the same brand, just encoded differently.
2. Is the `packages/ui` monorepo migration (§1) worth doing before or alongside Phase 7 backend wiring, given both touch every app substantially? Doing them together avoids double-touching every file, but makes each individually larger and riskier.
3. AF's Add Payment Method / Add Postback / Add Event features (currently dead buttons) — are these features intentionally not-yet-built (in which case disable/mark coming-soon), or was the handler simply never wired (in which case build it now)? This determines whether §3's AF fix is "disable" or "implement."

**No implementation from this document should begin until these three questions are answered and the risk-grouped list above is explicitly approved, per the audit's own process requirement.**
