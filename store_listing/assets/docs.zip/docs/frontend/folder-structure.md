# Folder Structure — Current & Recommended

## Current (all 5 apps, identical shape)

```text
src/
├── app/            # Next.js App Router — routes only, correctly kept free of business logic in all 5 apps
├── components/
│   ├── ui/         # shadcn/Radix primitives — the design system
│   ├── form/       # shared field-wrapper components (SA, PL, AD, UD have this; AF does not — see below)
│   └── <feature>/  # feature components, e.g. tenants/, offers/, affiliates/
├── config/         # flat list of *-data.ts mock files, one (or more) per resource
├── lib/            # pure helpers: utils.ts, chart-colors.ts, nav-active.ts, status-badge lookup maps
├── types/          # flat list of per-resource type files
└── hooks/          # only present in UD and PL; SA/AF/AD have no hooks/ folder at all
```

**Verdict: keep this shape.** It is not the "organized purely by technical type" anti-pattern the generic playbook warns about — feature separation already happens one level into `components/`, `config/`, and `types/`, which is a reasonable, Next.js-idiomatic structure for apps this size (dozens, not hundreds, of components per app). A `features/<name>/{components,hooks,api,types}` rewrite would be a large, low-payoff migration for the current app sizes and is **not recommended** (see target-architecture.md's "what NOT to do").

## What's actually wrong (placement, not shape)

1. **Generic components living inside a specific feature's folder.** SA's `components/affiliates/affiliates-pagination.tsx` is imported by advertiser/manager/offer/report pages; SA's `components/affiliates/affiliate-stepper.tsx` is imported by advertiser/manager add-forms too. This is a discoverability and ownership problem: a developer working on offers has no reason to look inside `affiliates/` for the pagination component they need to change.
   - **Rule going forward**: the moment a component is imported by a second, unrelated feature folder, it moves to `components/ui/` (if it's a primitive-level concern) or a new `components/shared/` (if it's a composed pattern like a details-modal shell or a table toolbar — see component-reuse-map.md).
2. **No `hooks/` folder in SA, AF, AD.** UD and PL both have one. Given every app needs a pagination/filter hook (see current-architecture.md §4/§10), every app should have this folder, even before any hook is extracted — consistency here costs nothing.
3. **`form/` package exists in 4 of 5 apps but not AF.** This isn't a folder-shape issue, it's a missing folder with real consequences (AF's accessibility gap in current-architecture.md §9 traces directly to this).

## Recommended folder additions (additive only, no renames required)

```text
src/
├── hooks/
│   └── use-paginated-list.ts   # NEW, one per app until a shared package exists (see target-architecture.md)
├── components/
│   ├── shared/                 # NEW — composed, cross-feature patterns that aren't primitives
│   │   ├── table-toolbar.tsx
│   │   ├── filter-select.tsx   # UD already has one of these in ui/ — promote the concept, don't duplicate it again
│   │   └── details-modal.tsx
│   └── ui/                     # unchanged — primitives only
```

`components/shared/` vs `components/ui/`: `ui/` stays reserved for primitives with no app-specific knowledge (Button, Card, Table, Dialog). `shared/` is for compositions that combine primitives into a recurring pattern specific to this product (a table with a search bar and pagination footer, a details-modal shell with an avatar+grid-of-fields layout) — these are not "generic UI," they encode this app's conventions, so they don't belong in a UI-primitives package that might one day be reused elsewhere.
