# Component Reuse Map

```text
Shared UI (components/ui/ — primitives, no app-specific knowledge)
   ↓
Shared Components (components/shared/ — proposed, composed cross-feature patterns)
   ↓
Feature Components (components/<feature>/ — this product's domain knowledge)
   ↓
Pages (app/**/page.tsx — composition only)
```

## Shared UI layer — current state

9 primitives audited across all 5 apps (button, card, table, badge, select, dialog, sheet, input, toggle-group). `badge.tsx` is the only one that's byte-identical everywhere. The rest have drifted — see current-architecture.md §6 for the full diff table. **This layer should become a real shared package** (see target-architecture.md) since it's already conceptually shared; today it's shared by copy-paste, which is why it has drifted.

## Shared Components layer — does not exist yet; these are the promotion candidates

| Proposed shared component | Currently duplicated as | Count | Notes |
|---|---|---|---|
| `Pagination` (+ `usePaginatedList` hook) | SA: 20+ list components with hardcoded `TOTAL_PAGES=10` and no-op filtering; AF/AD/UD: 5-9 similar call sites each; PL: 4 call sites with *real* logic | 5 apps × several call sites each | PL's implementation (real filter+slice+reset-to-page-1) is the correct reference — SA's is not just duplicated, it's decorative and should not be used as the template |
| `FilterBar` (search input + N selects) | SA: 21 near-identical `*-filter-bar.tsx`; AF: 5; AD: 2; UD: several | dozens across the workspace | Structure is consistent enough (search + 1-2 selects) to genuinely warrant one configurable component — this is a case where abstraction is justified, not over-engineering, because the behavior (search + filter, wire to state) is identical everywhere, only the option lists differ |
| `TableToolbar` | The exact `<div className="flex flex-wrap items-center justify-between gap-3 border-b border-border bg-[#F9FAFB] p-4 ...">` markup (with a raw hex color) repeated verbatim 5-7 times per app | ~25+ occurrences workspace-wide | Extracting this also fixes a design-token violation for free (§7 of current-architecture.md) |
| `DetailsModal` (avatar + title + grid-of-fields + close) | SA: 5 near-duplicate `*-details-modal.tsx`; UD: 2 | 7 occurrences | Read-only detail views only — do not conflate with the separate "Create" Dialog pattern |
| `EmptyState` | UD's `EmptyTableState` (used only by 3 Order Details sub-panels, explicitly commented as reusable but not reused elsewhere); PL's inline empty-state rows (3 places); SA's single instance | scattered, inconsistent | Once list+filter+pagination is real everywhere (via the shared `Pagination`/`usePaginatedList`), every list needs this — build it once, alongside that work, not before |
| `Stepper` | SA's `affiliate-stepper.tsx`, used by 3 forms — **currently fake** (hardcoded `activeStep={1}`) | 3 occurrences | Do not promote this as-is; fix or remove first (see target-architecture.md P0 items) |

## Feature Components layer

Correctly organized already (one folder per domain concept: `tenants/`, `offers/`, `affiliates/`, etc.) in all 5 apps. No structural change recommended here — see folder-structure.md.

## Pages layer

Already thin/composition-only in the apps checked (SA, PL, and spot-checked AF/AD/UD pages) — this is one of the few areas with no finding against it. Keep it that way as the Shared Components layer grows; the risk to watch is a shared component absorbing so many props/config options that a page ends up doing configuration logic instead of composition (see frontend-rules.md, rule on over-abstraction).
