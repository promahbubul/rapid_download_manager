# Current Frontend Architecture

Covers all 5 Next.js apps in this workspace: `tracking-super-admin-dashboard` (SA), `tracking-affiliate-dashboard` (AF), `tracking-advertiser-dashboard` (AD), `tracking-user-dashboard` (UD — manager-facing, legacy folder name), `tracking-platform-dashboard` (PL — built this session). Findings below are from direct code audit (3 parallel agents, all findings cross-checked against file paths/line numbers), not assumption.

## 1. Multi-app reality: no monorepo, no shared package

Confirmed: no root `package.json`, no `turbo.json`, no `pnpm-workspace.yaml`, no `lerna.json`/`nx.json` anywhere under `D:\projects\dice_track\`. SA, AF, AD, UD each have their own independent `.git` repo; PL has none yet. **Every "shared" piece of code — UI primitives, the `form/` field-wrapper package, `chart-colors.ts`, `nav-active.ts` — exists because it was copied file-by-file between apps, not imported from a common package.** This is the root cause behind nearly every other finding in this document: five copies drift independently the moment any one of them is edited.

## 2. Folder structure (per app)

All 5 apps share the same shape: technical-type at the top of `src/` (`app/`, `components/`, `config/`, `lib/`, `types/`, `hooks/` in 2 of 5), with feature separation one level down inside `components/<feature>/`. This hybrid is not the "pure technical-type" anti-pattern the generic playbook warns about — it's a reasonable, Next.js-idiomatic shape. The real problems are not "wrong folders," they're **inconsistent placement within that shape**:
- Generic, cross-feature components live inside a specific feature's folder because that's where they were first extracted: `affiliates-pagination.tsx` (SA) is imported by advertisers/managers/offers/reports pages despite living in `components/affiliates/`; `affiliate-stepper.tsx` (SA) is imported by advertiser/affiliate/manager add-forms. PL and AD, by contrast, correctly place their pagination in `components/ui/`.
- `config/` and `types/` are flat per-resource file lists (not colocated with the feature's components) in every app — consistent, at least, but means a "feature" is scattered across 3-4 top-level folders.

## 3. "Create" UX pattern — inconsistent within and across every app

No app applies a single rule. Concrete inventory:

| App | Real full-page creates | Dialog creates | Dead/non-functional "Add" affordances | Other |
|---|---|---|---|---|
| SA | 6 (advertiser, affiliate, group, manager, offer, support-ticket — **support-ticket is only 4 fields**, arguably should be a modal) | 0 (Dialog used only for read-only detail views) | 0 | **3 forms have a decorative multi-step "stepper" hardcoded to `activeStep={1}` that never advances** (advertiser/affiliate/manager add-forms) — fake wizard chrome on a single-page form. **5 settings sections have a 4th, undocumented pattern**: an "Add X" mini-form permanently inline in the page with no open/close state at all (faqs, offer-category, offer-traffic-type, signup-question, tracking-domains) |
| AF | 0 | 1 (Edit Profile, ~5 fields, **uncontrolled inputs, no validation at all**) | 2 (Add Payment Method button-grid, "Add Postback"/"Add Event" buttons — all have no `onClick`) | No create flow exists in this app at all |
| AD | 1 (Create Campaign, ~28 fields, genuinely multi-step, justified) | 1 (Edit Profile, ~5 fields, **properly wired with react-hook-form**, unlike AF's equivalent) | 1 (Add Payment Method, same dead button-grid as AF) | |
| UD | 1 (Add Affiliate, 13 fields, justified) | 2 (read-only Affiliate Details, Edit Profile) | 1 (Add Payment Method dead button-grid) | 1 stub: Add Offer route renders `<ComingSoon />`, no form at all |
| PL | 2 (Add Tenant 7 fields, Add Plan 12 fields) | 0 | 0 | Most disciplined of the 5 — no stepper theater, no dead buttons — but 7-field tenant form is borderline modal-sized |

## 4. State management

No app uses Zustand/Redux/React Query/SWR anywhere (confirmed via `package.json` + source grep in all 5). All state is local `useState`. This is currently *appropriate* — there is no async data yet (see current-state.md) — but the **list+filter+pagination logic is reimplemented from scratch in every single list component**, with two very different quality levels:

- **SA: 20+ list components share an identical but non-functional pattern** — `const TOTAL_PAGES = 10` (hardcoded, never derived from data length), the table child is rendered with **zero props**, so pagination UI moves but content never changes, and filter `Select`s are uncontrolled (`defaultValue` only). This is decorative UI, not a working feature.
- **AF/AD/UD: same shape, same problem** — filters uncontrolled, pagination state exists but doesn't slice the underlying array (UD's `OfferApprovalList` is the one working exception, using real `.filter()` on `activeTab`).
- **PL: the only app where list+filter+pagination is fully real** — search/status filters are controlled state, pagination correctly slices the filtered array and resets to page 1 on filter change, empty states render when a filter matches nothing. Still duplicated near-verbatim across 4 files with no shared hook.
- UD is the only app with any shared hooks at all: `src/hooks/use-pagination.ts` and `use-row-selection.ts` — but `use-pagination.ts` is still called with a hardcoded `usePagination(10)` in every list, so the hook exists but doesn't fix the underlying "not derived from real data" problem.

## 5. API/service layer

**None exists in any of the 5 apps.** No `src/lib/api`, no `src/services`, no `fetch`/`axios`/`useQuery`/`useSWR` anywhere in any app's source (confirmed by grep, zero hits across all 5). Every component imports mock data directly from `src/config/*-data.ts` — 88 files in SA, 22 in PL, similar density in AF/AD/UD. This is consistent with every app being pre-backend-integration (see `docs/analysis/current-state.md`), but it means **every one of these direct imports will need to become a hook call when Phase 7 wiring begins** — there is no single seam to change today.

## 6. Component duplication

**Within each app**, the dominant pattern is near-identical filter bars and table toolbars copy-pasted per feature:
- SA: 21 separate `*-filter-bar.tsx` files, structurally near-identical (search + 1-2 selects); 5 near-duplicate `*-details-modal.tsx` Dialogs.
- AF: 5 filter bars, diffed pairwise as literal copies differing only in imported option constants; every table repeats the same toolbar `<div>` markup (with a raw hex background, see §7) verbatim across 6 files.
- AD: has a shared `search-input.tsx` (better factored than AF for search), but the Select-based filter dropdown block is still copy-pasted across 2 files; toolbar markup repeated across 6 files.
- UD: same toolbar-repetition pattern across 7 table components.
- PL: minimal — 1 filter bar, 1 pagination component, correctly shared.

**Across apps**, the `components/ui/` primitive set (button, card, table, badge, select, dialog, sheet, input, toggle-group) was checked file-by-file:
- SA ≡ PL ≡ AD are byte-identical on most files (button, card, sheet, input; table/select agree with AD too).
- AF is a near-copy of that cluster with small intentional divergences (dialog restyled with `rounded-xl`/always-visible close button, different table header color, drops the unused `SelectGroup` export).
- **UD has diverged from all 4 on every file except `badge.tsx`** — same component shapes/props (so nothing is broken), but different formatting convention (semicolons, different line-wrap width) plus genuine visual differences: an extra `brand` gradient button variant, a bordered card instead of a ring, literal-hex table header color instead of a token.
- `badge.tsx` is the one fully unified primitive across all 5 apps.

## 7. Design tokens — the CHART_SLOT_VAR/CLASS system exists but is bypassed extensively

`src/lib/chart-colors.ts` (identical file in SA/PL/AF/AD/UD) defines the sanctioned token API: `CHART_SLOT_VAR` (CSS var refs, for Recharts props that can't take Tailwind classes) and `CHART_SLOT_CLASS` (Tailwind classes, for tiles/badges/meters). Raw hex color counts found bypassing it:

| App | Raw hex hits (components/ + config/) | Worst offenders |
|---|---|---|
| SA | 126 | `performance-chart.tsx` (chart series colors), `cr-optimizer-table.tsx`, `offer-approval-table.tsx`, `nav-link*.tsx` (brand green hardcoded 7+ times), **even the shared `ui/` primitives** (`checkbox.tsx`, `switch.tsx`, `toggle-group.tsx`, `image-dropzone.tsx`) |
| AF | 24 | Same `ui/` primitive offenders (shared files with SA) + `performance-chart.tsx`, `category-badge.tsx`, table toolbars |
| AD | 20 | Same `ui/` primitive offenders + `campaigns-table.tsx`, `payment-methods-card.tsx`, `rich-text-editor.tsx` |
| UD | ~14 | `performance-chart.tsx`, `category-badge.tsx`, table toolbars, several `ui/` primitives |
| PL | 21, **all confined to the inherited boilerplate files** (nav-link, checkbox, switch, toggle-group, image-dropzone, rich-text-editor) — **zero in any chart/data-display component or config file** | The one app where new code doesn't repeat the anti-pattern |

**A specific bug, not just a style issue**: `tracking-advertiser-dashboard`'s `globals.css` defines **no `--chart-1` through `--chart-8` tokens at all** — the other 4 apps define identical hex values for these. If any future AD chart component references `CHART_SLOT_VAR`, it will silently fall back to whatever `shadcn/tailwind.css` provides, which will not visually match the other 4 apps' charts.

**Also a bug**: `tracking-user-dashboard` encodes `--brand-start`/`--brand-end` as plain hex while the other 4 apps use `oklch()` for the same intended colors, and uniquely defines a `--brand-gradient` CSS variable the other apps don't have (matching its uniquely-diverged `button.tsx`). The 4 non-UD apps' brand colors are otherwise identical.

## 8. Loading / Error / Empty states

**Loading and error states do not exist in any app** — zero `isLoading`/`Skeleton`/`isError` patterns found anywhere, consistent with there being no async data yet.

**Empty states are inconsistent and correlate directly with whether an app's filtering is real (§4)**:
- SA: exactly 1 real empty-state message in the whole app (`group-members-picker.tsx`) — everywhere else, "empty" never happens because filtering is decorative.
- AF: a few detail-panel empty states (Order Details sub-panels), but the primary list tables have none.
- AD: same pattern — sub-panel empty states (cap/landing-page/payout tables) exist, primary lists don't.
- UD: 3 empty-state messages, all in Order Details sub-panels via a shared `EmptyTableState` component that is explicitly commented as reusable but is **not** reused by the main affiliates/offers/reports lists.
- PL: 3 empty-state messages, each backing a genuinely-working filter (tenants, invoices, users) — the only app where "empty" is a real, reachable UI state.

## 9. Accessibility

Baseline is solid everywhere because every app wraps Radix primitives (`dialog.tsx`, `select.tsx`, `sheet.tsx` all import from the `radix-ui` package) — focus trapping, Escape-to-close, roving tabindex in `Select`, and accessible-name wiring for the mobile nav `Sheet` (`SheetTitle`/`SheetDescription`, both `sr-only`, present in all 5 apps identically) all come for free and were confirmed present in source.

Gaps are specific and repeat across apps:
1. **Ad hoc, unlabeled form fields where an app skips the shared `form/` package**: AF's `edit-profile-modal.tsx` defines its own local `FormField` helper with no `htmlFor`/`id` association — the one clear case found. SA, AD, UD, PL all use the shared `form/form-field.tsx`/`select-field.tsx`, which correctly wire `React.useId()` → `htmlFor`/`id` and propagate `aria-invalid` — confirmed by source inspection in all four.
2. **Filter-bar `Select`s have no visible or programmatic label** in most instances across all 5 apps (UD's `FilterSelect` primitive, AF's/AD's inline filter Selects) — a screen-reader user hears only the currently-selected value, not what the control filters. One exception: AF's `reports-filter-bar.tsx` wraps each Select in a local `FilterField` with a visible (but not `aria`-linked) label.
3. **Two Dialogs found missing `DialogDescription`**: AD's `edit-profile-dialog.tsx` uses a plain `<p>` instead (breaks Radix's `aria-describedby` wiring, logs a dev warning); UD's `AffiliateDetailsModal` has a `DialogTitle` but no description at all.
4. SA's decorative stepper (§3) is also a soft accessibility issue: it presents as a "step 1 of N" landmark that never advances, which could mislead a screen-reader user into thinking navigation is possible.

## 10. Pagination — the single most duplicated and most functionally inconsistent piece of code in the workspace

Reimplemented independently 5 times (once per app), with 3 different quality levels: SA's (~20+ call sites) is decorative and non-functional; AF/AD/UD's (5-6 call sites each) mixes decorative and one real exception (UD's offer-approval); PL's (4 call sites) is the only fully real implementation, itself duplicated 4x with no shared hook. No app has a single source of truth for "what does pagination + filtering actually do."
