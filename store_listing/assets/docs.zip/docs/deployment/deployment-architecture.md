# Deployment Architecture

**Current state: no Dockerfile, no docker-compose.yml, and no CI/CD workflow exist anywhere in the repository.** This session manually started a Postgres container by hand for local development because no committed way to do so exists.

## Environments

Development → Staging → Production (3-tier, matches every legacy planning document's agreement on this point).

## Domain Layout (target, not yet configured)

```text
app.<domain>    → Next.js dashboards (4 apps, or unified once brand question is resolved)
api.<domain>    → NestJS GraphQL API
track.<domain>  → NestJS REST tracking/postback endpoints (same deployable as api., different route prefix — see backend-architecture.md)
```

## Local Development (target)

`docker-compose.yml` at repo root (tracking-api), providing:
- `postgres:16` (already validated working in this session)
- `redis:7` (once V1 introduces caching/queueing)

## CI/CD (target, not yet implemented)

Pipeline stages: checkout → install → lint → test (once tests exist) → build → (on merge to main) `prisma migrate deploy` → deploy.

## Secrets & Configuration

- `.env.local` (dev) / `.env.prod` (production) via `dotenv`, already the established pattern — keep it.
- Required keys already enforced via `env.validation.ts`; `JWT_REFRESH_SECRET` should be added to the required list (security-architecture.md Gap #5).
- No secrets manager needed at current scale (Open Question territory for V1+ if compliance requirements — Open Question #7 — demand it).

## Migrations

- `prisma migrate deploy` in production (already the correct command, already used in this session) — never `prisma db push` against production data.
- Migration status should be a CI gate before deploy, not a manual step.

## Backups

- Daily PostgreSQL backup (logical dump or managed-provider snapshot) — not currently automated. This is flagged as a Phase 1 requirement even before MVP feature work, since there will be real tenant data as soon as the first tenant onboards.

## Monitoring/Rollback

- Sentry for error tracking (see non-functional-requirements.md) — add in Phase 1, cheap and high-value.
- Rollback strategy: since this is a modular monolith with a single deployable, rollback = redeploy the previous container image + `prisma migrate resolve` if a migration needs reverting. No blue/green or canary deployment is justified at current scale.

## SSL/CDN

- Cloudflare in front of all three domains (`app.`/`api.`/`track.`) for SSL, DNS, and basic WAF/DDoS protection — consistent with every legacy planning document.

This entire file describes a **target**, not a current capability — see [`../analysis/current-state.md`](../analysis/current-state.md) for what infrastructure genuinely exists today (none).
