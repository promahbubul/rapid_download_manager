# Scalability Strategy

Staged by actual measured volume, not adopted pre-emptively (over-engineering the initial system is explicitly avoided per the planning mandate).

| Stage | Volume | Database/Analytics | Cache/Queue | Compute |
|---|---|---|---|---|
| 1 (current) | ~0–10K events/day | PostgreSQL only; existing `[tenantId, createdAt]`-style composite indexes are sufficient | None | Single NestJS process |
| 2 | ~1M events/day | PostgreSQL + scheduled `ReportSnapshot` pre-aggregation job | Redis (hot dashboard reads) | Single process, vertically scaled if needed |
| 3 | ~10M events/day | ClickHouse for raw `Click`/`Conversion` events; PostgreSQL remains OLTP source of truth for `Offer`/`Affiliate`/`Payout`/etc. | Redis + BullMQ (background jobs off the request path) | Possibly split Tracking API from Main API into 2 deployables (same codebase, different entrypoints) |
| 4 | 100M+ events/day | ClickHouse partitioned by tenant/time | BullMQ; consider Kafka only if BullMQ genuinely cannot keep up | Horizontally scaled tracking service behind a load balancer |

## Anticipated Bottlenecks

- **Database**: the `Click`/`Conversion` tables will be the largest by row count; the composite indexes already in the schema (`[tenantId, createdAt]`, `[tenantId, offerId, createdAt]`, `[tenantId, affiliateId, createdAt]`) make the eventual Stage 3 migration to ClickHouse a data-export exercise, not a redesign.
- **API**: the `/go/{code}` redirect path is latency-critical (<100ms target); dashboard GraphQL queries are not.
- **CPU**: fraud scoring is currently planned as synchronous/fire-and-forget for MVP — this is the first thing that must move to a queue (Stage 2) once volume makes it a measurable redirect-latency cost.
- **Queue**: not applicable until Stage 2 introduces one.
- **Storage**: `Click.userAgent`/`referrer` are unbounded text fields; monitor row size growth once real traffic exists — no current mitigation needed at Stage 1 volume.

## Explicit Non-Goals for Now

Do not introduce ClickHouse, Kafka, Kubernetes, or a multi-service split at Stage 1 or Stage 2. See [`../decisions/adr-log.md`](../decisions/adr-log.md) ADR-001, ADR-004, ADR-005.
