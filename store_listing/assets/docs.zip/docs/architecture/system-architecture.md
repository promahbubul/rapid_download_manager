# System Architecture

## Architecture Style Decision: Modular Monolith

Evaluated against the required criteria:

| Criterion | Assessment | Implication |
|---|---|---|
| Business complexity | Moderate (19 identifiable modules, but most logic per module is straightforward CRUD + one genuinely complex module: tracking/fraud) | Doesn't need service-per-team decomposition |
| Team size | Small (evidenced by a single backend repo built incrementally, no multi-team ownership signals) | Microservices' coordination overhead has no team to absorb it |
| Expected traffic | Currently zero in production; staged growth plan exists (see scalability.md) | No current justification for distributed infrastructure |
| Data complexity | Moderate-high (21 relational entities, heavy cross-entity queries for reporting) | Favors a single relational database with strong consistency, not distributed data ownership |
| Deployment complexity | Must stay low (no CI/CD, no Docker, no orchestration exists yet) | A single deployable artifact is achievable now; multiple services are not |
| Cost | Sensitive (early-stage SaaS) | One database, one compute unit is cheapest to run and operate |
| Maintainability | NestJS's module system already provides logical boundaries (`src/modules/*`) | Physical service boundaries can be introduced later at the existing module seams, cheaply |
| Future scalability | The one component with a distinct scaling profile is the tracking/redirect path (Section: Tracking) | This is the one candidate for eventual physical separation — not Day 1 |

**Decision**: NestJS modular monolith, single deployable, through MVP and V1. Do not adopt microservices, Kubernetes, Kafka, or a separate physical tracking service until the queue-based V1 architecture is running and a specific, measured bottleneck justifies the split (see ADR-001).

## High-Level Architecture

```mermaid
flowchart TD
    subgraph Client
        Dash[4 Next.js Dashboards]
        Visitor[End Visitor Browser]
        AdvServer[Advertiser Server]
    end

    subgraph Edge
        CF[Cloudflare - DNS/SSL/WAF]
    end

    subgraph Backend[tracking-api - single NestJS deployable]
        GQL[GraphQL API - dashboard]
        REST[REST API - /go, /postback]
        Guard[Global Auth Guard + RolesGuard + Tenant Context]
        Services[Domain Services]
    end

    subgraph Data
        PG[(PostgreSQL - source of truth)]
        Redis[(Redis - V1)]
        CH[(ClickHouse - V2)]
    end

    Dash -->|GraphQL, JWT| CF --> GQL
    Visitor -->|GET /go/code| CF --> REST
    AdvServer -->|POST /postback + secret| CF --> REST
    GQL --> Guard --> Services --> PG
    REST --> Guard --> Services --> PG
    Services -.V1.-> Redis
    PG -.V2.-> CH
```

## Internal/External Services Inventory

| Component | Now | V1 | V2 |
|---|---|---|---|
| Cache | — | Redis | Redis |
| Queue | — | BullMQ (on Redis) | BullMQ |
| Object storage | — | — | S3/R2 (if file uploads are ever needed — none required by current FRs) |
| Search | — | — | Not currently required by any FR |
| Workers | — | 1 worker process consuming BullMQ | Scaled workers |
| Scheduler | — | Cron job for `ReportSnapshot` pre-aggregation | — |
| Notification | — | Email (SES/SendGrid) + in-app | + SMS/push if a future FR requires it |
| Error tracking | Sentry (recommended Day 1 of MVP, not yet added) | Sentry | Sentry |
| Analytics DB | — | — | ClickHouse |
| Payments | — | Stripe (subscriptions) | + PayPal/Wise (automated payout) |
| Fraud signals | Internal rules only | Internal rules only | IPQualityScore, Fingerprint, MaxMind |

See [`frontend-architecture.md`](frontend-architecture.md), [`backend-architecture.md`](backend-architecture.md), and [`scalability.md`](scalability.md) for detail.
