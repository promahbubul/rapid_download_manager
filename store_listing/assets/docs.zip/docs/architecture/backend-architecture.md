# Backend Architecture

## Layer Responsibilities (NestJS)

| Layer | Responsibility | Current state |
|---|---|---|
| Resolvers (GraphQL) / Controllers (REST) | Parse input, apply guards, delegate to services, shape output | Only `auth`/`users` resolvers exist |
| Services | Business logic, orchestrate repository calls, enforce business rules | Only `AuthService`/`UsersService` exist |
| Repositories | Currently implicit — `PrismaService` injected directly into services rather than a separate repository layer | Acceptable for current scale; introduce explicit repositories only if a service starts mixing too much query logic with business logic |
| DTOs | Input shape + `class-validator` rules | Exist for `auth` module only (`SignInInput`, `RegisterLocalInput`, `GoogleSignInInput`) |
| Guards | Auth/role/tenant enforcement | `GqlJwtAuthGuard`, `GqlThrottlerGuard` exist; `RolesGuard` and tenant-context guard **do not exist** — critical gap |
| Events | Domain events for decoupling (e.g. `conversion.received`) | Not implemented — deferred to V1 with BullMQ |
| Workers | Background job processors | Not implemented — deferred to V1 |
| Integrations | Third-party API clients (Stripe, Google, fraud APIs) | Only `google-auth-library` (for Google Sign-In) exists |

## Module Structure (existing, to be filled in per roadmap)

```text
src/
├── common/           # cross-module decorators, enums
├── config/           # env loading, per-domain config factories
├── database/         # PrismaService, seeds, base entity classes
├── modules/
│   ├── auth/         # IMPLEMENTED
│   ├── users/        # IMPLEMENTED
│   ├── tenants/      # stub
│   ├── advertisers/  # stub
│   ├── affiliates/   # stub
│   ├── offers/       # stub
│   ├── campaigns/    # stub
│   ├── tracking-links/ # stub
│   ├── clicks/       # stub — MVP priority
│   ├── conversions/  # stub — MVP priority
│   ├── fraud/        # stub
│   ├── payouts/      # stub
│   ├── reports/      # stub
│   ├── subscriptions/# stub — V1
│   ├── billing/      # stub — V1
│   ├── webhooks/     # stub — V1
│   ├── api-keys/     # stub — V1
│   ├── notifications/# stub
│   ├── audit-logs/   # stub
│   └── health/       # IMPLEMENTED (trivial)
├── app.module.ts
└── main.ts
```

No new top-level modules are needed — the 19 that exist already match the target scope (see [`../analysis/current-state.md`](../analysis/current-state.md)). Work is filling in the 17 stubs in the order defined in [`../roadmap/development-roadmap.md`](../roadmap/development-roadmap.md).

## Cross-Cutting Concerns to Introduce (Phase 1, before any new module)

1. Global `APP_GUARD` for authentication (default-deny, `@Public()` opt-out) — currently only `GqlThrottlerGuard` is global.
2. `RolesGuard` + `@Roles()` decorator.
3. Tenant-context propagation — recommended approach: a Prisma Client Extension or `AsyncLocalStorage`-backed request context that every query reads `tenantId` from, rather than each service remembering to add `where: { tenantId }` by hand.
4. `AuditLog` write helper, called from a shared interceptor on mutating operations by elevated roles (BR-012).
