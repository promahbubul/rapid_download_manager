# Frontend Architecture

## Current State (4 independent Next.js apps)

| App | Serves role | Brand | Next.js | Auth | Backend wired? |
|---|---|---|---|---|---|
| `tracking-super-admin-dashboard` | Tenant Admin (`SUPER_ADMIN`) | Dicetrack | 16.3.5 | Mock UI only (localStorage) | No |
| `tracking-user-dashboard` | Manager (`MANAGER`) | AffiliatePro | 16.3.4 | None | No |
| `tracking-advertiser-dashboard` | Advertiser | AffiliatePro | 16.3.4 | None | No |
| `tracking-affiliate-dashboard` | Affiliate | AffiliatePro | 16.3.5 | None | No |

All four: React 19.2.8, Tailwind v4, shadcn-style primitives, App Router only. No shared package/monorepo tooling — each is fully independent, synced by manually copying screens (documented in each app's `AGENTS.md`).

## Target Frontend Architecture

### Data layer (not yet built in any app)
- GraphQL client: Apollo Client, matching the backend's Apollo Server.
- No REST client needed on the frontend — the only REST endpoints (`/go`, `/postback`) are not called by dashboards, only by browsers and advertiser servers directly.

### State management (not yet built)
- Server state: Apollo Client cache (covers most dashboard needs — lists, detail views).
- Client-only UI state (modals, wizards, filters not yet submitted): local `useState`, as already used.
- A global client-state library (Zustand/Redux) is **not** recommended unless a genuine cross-page client-only state need emerges — none has so far.

### Recommended folder structure (applies uniformly to all 4 apps going forward)

```text
src/
├── app/              # routes only — no business logic
├── components/
│   ├── ui/           # generic primitives (already exists)
│   └── <feature>/    # feature-specific components (already exists)
├── config/           # currently mock data; becomes GraphQL query/fragment definitions
├── lib/
│   ├── api/          # Apollo client setup, generated types (NEW)
│   └── ...           # existing pure helpers
├── hooks/            # data-fetching hooks wrapping Apollo (NEW, consistent across apps)
└── types/
```

### Authentication (not yet built in any app)
- Wire to `tracking-api`'s existing `registerLocal`/`signInLocal`/`signInWithGoogle`/`me` GraphQL operations.
- Store access token in memory (Apollo `InMemoryCache` + auth link), refresh token in an httpOnly cookie set by the backend — not `localStorage` (current mock implementation in `super-admin-dashboard` is insecure by design and must not be extended, only replaced).
- Route guard via Next.js middleware, checking session validity before rendering protected routes — none of the 4 apps have a `middleware.ts` today.

### Cross-app consistency (structural recommendation, not a technology mandate)
- Introduce shared tooling (Turborepo or pnpm workspaces) to host a common `ui`/`config` package once brand unification (Open Question #3) is resolved — this addresses the already-observed drift risk (e.g. the accidental Dicetrack/AffiliatePro copy-paste documented in `tracking-user-dashboard`'s own `AGENTS.md`). This is a V1 recommendation, not MVP-blocking.

See [`../roadmap/development-roadmap.md`](../roadmap/development-roadmap.md) Phase 7 for when dashboard wiring is scheduled.
