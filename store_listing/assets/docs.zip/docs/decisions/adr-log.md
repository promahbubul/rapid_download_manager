# Architecture Decision Records

## ADR-001: Modular Monolith over Microservices

- **Context**: 19 backend modules exist as folders; only 2 have real logic; team size and traffic are both effectively zero in production today.
- **Options**: (a) Microservices per domain, (b) Modular monolith, (c) Fully separate frontend-per-service.
- **Decision**: Modular monolith — single NestJS deployable, strict module boundaries in code.
- **Reason**: No current traffic, team, or data-ownership pressure justifies distributed-systems overhead (network calls, service discovery, distributed transactions). Module boundaries already exist in the folder structure, making a future physical split cheap if a specific bottleneck (most likely the tracking/redirect path) ever demands it.
- **Trade-offs**: Slower to scale a single hot module independently; acceptable at current and near-term projected scale (see scalability.md).
- **Consequences**: Revisit only when a measured, specific bottleneck exists — not preemptively.

## ADR-002: REST for Tracking/Postback, GraphQL for Dashboard

- **Context**: Legacy docs universally agree on this split in principle, but one legacy doc's postback example contradicts it by having the advertiser dictate the payout amount, and click-link formats varied across 3 schemes over time.
- **Decision**: REST for `/go/{trackingCode}` and `/postback` (public, latency-critical, secret-authenticated); GraphQL for all dashboard operations (JWT-authenticated, tenant/role-scoped). Click links use the opaque `TrackingLink.trackingCode` only — never raw entity IDs.
- **Reason**: Matches the strongest and most consistent cross-document consensus; opaque codes prevent ID enumeration; REST is simpler and faster for the two narrow, high-volume, public endpoints.
- **Consequences**: Any new tracking-adjacent endpoint must justify why it isn't REST before being added as GraphQL, and vice versa for dashboard features.

## ADR-003: Shared-Database Multi-Tenancy via `tenantId` Column

- **Context**: No legacy document proposes schema-per-tenant or database-per-tenant; the shipped schema already uses a shared-database, `tenantId`-column approach across all 21 models.
- **Decision**: Continue with shared-database, row-level tenant isolation.
- **Reason**: Simpler operationally (one database to migrate/back up/monitor) and sufficient at the customer scale this SaaS targets (small-to-mid networks, not hundreds of enterprise tenants each demanding physical isolation).
- **Consequences**: Tenant-isolation enforcement must happen in application code (see security-architecture.md Gaps #2–#4) since the database itself does not physically separate tenants. This is a stricter requirement on code discipline than schema-per-tenant would be — mitigated by the recommended Prisma extension/AsyncLocalStorage approach rather than manual per-query filters.

## ADR-004: Defer Redis/BullMQ Until the MVP Synchronous Loop Works

- **Context**: 3 of 4 legacy phase-planning docs place Redis/BullMQ in "Phase 1"; one explicitly excludes it. None of it is implemented today, and there is currently no click volume to process.
- **Decision**: Build the MVP click→postback→conversion loop fully synchronously (fire-and-forget for non-critical side effects like fraud scoring) before introducing any queue infrastructure.
- **Reason**: Avoids operating infrastructure with nothing yet to process; matches the single most-repeated "build order" guidance across the legacy docs, which is also the one guidance not yet followed.
- **Consequences**: MVP fraud scoring and click writes happen inline; must be revisited (Stage 2, scalability.md) once real volume makes the redirect-latency cost of inline processing measurable.

## ADR-005: Defer ClickHouse Until Stage 3 Volume (~10M events/day)

- **Context**: Every legacy document that addresses timing agrees ClickHouse is a later-stage concern; one doc's stack table lists it without a phase qualifier, causing ambiguity.
- **Decision**: PostgreSQL only through Stage 1 and Stage 2; introduce ClickHouse only at Stage 3.
- **Reason**: Current production event volume is zero; the composite indexes already in the schema make this migration a data-export exercise later, not a redesign now.
- **Consequences**: `ReportSnapshot` (already modeled) carries the pre-aggregation burden at Stage 2 instead.

## ADR-006: Introduce an Immutable `LedgerEntry` Model Before Automating Payouts

- **Context**: `Affiliate.balance`/`reservedBalance` are mutable fields updated via `increment` inside the conversion transaction. No document or the schema itself distinguishes "commission earned" from "payment made" as separate, reconcilable events.
- **Options**: (a) Keep mutable balance only, add manual reconciliation tooling later; (b) Add an append-only `LedgerEntry` model now; (c) Add it only when automated payout (V2) is built.
- **Decision**: Add `LedgerEntry` in V1, before automated payout, but after MVP manual payout ships.
- **Reason**: A mutable-only balance cannot be reconciled or audited if a conversion is reversed/charged back; retrofitting a ledger after automated payout exists is riskier than building it just before that feature.
- **Consequences**: Requires a schema migration and a change to how `Affiliate.balance` is derived — flagged as needing explicit approval (see Open Questions #13).

## ADR-007: Retain bcrypt over argon2

- **Context**: Several legacy docs recommend argon2 "if possible"; the shipped code uses bcrypt.
- **Decision**: Keep bcrypt.
- **Reason**: Already implemented and cryptographically adequate for this use case; switching has a real migration cost (re-hashing on next login, or dual-support code) with no concrete security requirement forcing the change.
- **Consequences**: Revisit only if a specific compliance or security audit requirement mandates argon2.

## ADR-008: Opaque `trackingCode` Instead of Raw Entity IDs in Public URLs

- **Context**: 3 different click-link URL schemes appear across legacy docs over time (raw IDs → short codes → opaque code); the shipped schema's `TrackingLink.trackingCode` field matches only the newest scheme.
- **Decision**: `GET /go/{trackingCode}` is the only supported public tracking URL format.
- **Reason**: Prevents ID enumeration/guessing of internal offer/affiliate identifiers; already matches the schema, requiring no migration.
- **Consequences**: None of the older URL formats described in legacy docs should be implemented, even though they appear more than once in the doc history.
