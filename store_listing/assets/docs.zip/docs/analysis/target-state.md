# Target State Analysis

This describes the intended architecture once the roadmap's MVP (Phase 1–6) and V1 (Phase 7) are complete. **Nothing in this document is implemented yet — it is a target, not a status report.**

## Target Architecture

Modular monolith (ADR-001) with a hardened security foundation (all 7 gaps in security-architecture.md fixed), serving REST for tracking/postback and GraphQL for dashboards (ADR-002), backed by a single PostgreSQL database with `tenantId`-enforced isolation (ADR-003) via an AsyncLocalStorage/Prisma-extension mechanism rather than manual per-query filters.

## Target Modules

All 17 currently-stub modules filled in per the [`../roadmap/development-roadmap.md`](../roadmap/development-roadmap.md) phase order — no new modules beyond what already exists as folders.

## Target Database

The 21 existing models plus two additive changes: a `LedgerEntry` model (ADR-006) and `Offer.attributionWindowDays` (see database-design.md "Planned Additions"). No other schema changes are indicated by this analysis.

## Target APIs

The full REST + GraphQL surface documented in [`../api/api-specification.md`](../api/api-specification.md), all endpoints authorization-checked per [`../business/role-permission-matrix.md`](../business/role-permission-matrix.md), all high-volume list queries (Click, Conversion, AuditLog) using cursor-based pagination.

## Target Frontend

4 dashboards (or fewer, pending Open Question #3's resolution), each with real Apollo Client GraphQL integration, real JWT-based authentication (httpOnly refresh cookie, in-memory access token — not the current localStorage mock), and route guards via Next.js middleware. A 5th, platform-level dashboard added once Open Question #2 is resolved.

## Target Security Posture

All 7 currently-known gaps closed; `AuditLog` populated by every elevated-role mutation; postback endpoints secret/signature-verified from their very first implementation (not retrofitted); MFA available for `TENANT_ADMIN`/`PLATFORM_OWNER` roles (V1).

## Target Testing Posture

No module ships without unit + integration tests covering its documented FR's main/alternative/failure flows (testing-strategy.md); the `/go/{code}` path has a load-test gate before being declared MVP-complete.

## Target Infrastructure

`docker-compose.yml` for local dev (Postgres + Redis once V1), a CI/CD pipeline running lint/test/build/migrate/deploy, Sentry + structured logging from Phase 1, daily automated Postgres backups.

## Target Financial Model

Conversions credit an immutable `LedgerEntry`, not a bare `balance` increment; `Affiliate.balance` becomes a derived value; payout workflow enforces the BR-009 state machine in code, not just convention.

## What Is Explicitly NOT Part of the Target State (near-term)

Microservices, Kubernetes, Kafka, Rust, ClickHouse, third-party fraud APIs, automated payout, commission precedence rule engine, white-label/multi-region/self-hosting — all deferred per their respective ADRs and roadmap phases, not because they are bad ideas, but because nothing in the current or near-term projected state justifies their operational cost yet.
