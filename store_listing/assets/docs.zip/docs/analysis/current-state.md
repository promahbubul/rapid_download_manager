# Current State Analysis

## Current Architecture

- Backend: NestJS 11 + GraphQL (Apollo Server 5) + Prisma 6.16.2 + PostgreSQL. Single deployable, no queue/cache/analytics infrastructure (`ioredis`, `bullmq`, `@nestjs/bullmq`, any ClickHouse client, `nestjs-pino`, `@sentry/node` — all absent from `package.json`).
- Frontend: 4 independent Next.js 16 / React 19 repos, no shared package, no monorepo tooling.

## Current Modules (backend)

19 module folders exist: `advertisers, affiliates, api-keys, audit-logs, auth, billing, campaigns, clicks, conversions, fraud, health, notifications, offers, payouts, reports, subscriptions, tenants, tracking-links, users, webhooks`.

**Only `auth` and `users` have real implementation** (resolver, service, DTOs, guards). All other 17 are `@Module({})` stubs with only an `entities/` folder — confirmed by direct inspection of `offers.module.ts` and the `clicks` module directory.

## Current Database

21 Prisma models, 28 enums, fully migrated (4 migrations applied). See [`../database/database-design.md`](../database/database-design.md) for the full data dictionary. This is the most mature part of the project — more advanced than any single legacy planning document's own data model proposal.

## Current APIs

Implemented GraphQL operations only: `registerLocal`, `signInLocal`, `signInWithGoogle`, `me`, `users`. No REST tracking/postback endpoints exist. No public API exists.

## Current Frontend State

- All 4 dashboards render exclusively from static `src/config/*-data.ts` mock files.
- Zero GraphQL/REST client code, zero `fetch(` calls, zero `.env` files, in any of the 4 apps.
- No state management library in any app.
- Only `tracking-super-admin-dashboard` has sign-in UI, and it is a non-functional mock (localStorage only, no network call, no credential verification).
- Two unreconciled brand names: "Dicetrack" (super-admin) vs. "AffiliatePro" (the other three).
- Zero tests in any of the 4 apps.

## Current Strengths

1. Database schema is well-normalized, correctly tenant-scoped (`tenantId` + composite indexes on every relevant table), and uses `Decimal` for all money fields.
2. REST-for-tracking / GraphQL-for-dashboard architectural split is already decided and consistent with the auth module's implementation.
3. NestJS module folder structure already matches the target module list — no restructuring needed, only filling in.
4. Frontend tech choices (Next.js 16, React 19, shadcn) are modern and consistent across all 4 apps.

## Current Weaknesses (Technical Debt)

1. No authorization layer at all beyond "is logged in" — see security-architecture.md Gaps #1–#4.
2. `toUser()` silently discards real column data on every read (Gap #7).
3. Refresh-token secret and duration-parsing bugs (Gaps #5–#6).
4. Zero tests anywhere, zero CI/CD, zero Dockerfile/docker-compose.
5. The single most business-critical feature (click→postback→conversion) is entirely unbuilt, despite the database being fully ready for it.
6. Frontend has no backend connectivity of any kind — this is a full build, not a "wire it up" task.
7. Two unreconciled product brand identities across the 4 dashboards.
8. `Affiliate.balance` is a mutable running total with no immutable audit trail (see ADR-006).

## Gap Analysis (Planned vs. Actual)

| Area | Legacy docs' intent | Actual state |
|---|---|---|
| Click/postback/conversion engine | "The heart of the system," Phase 1 priority in every doc | 0% implemented |
| Redis/BullMQ | 3 of 4 docs treat as Phase-1-ish | 0% implemented, correctly deferred per ADR-004 |
| ClickHouse | Universally agreed as later-stage | 0% implemented, correctly deferred per ADR-005 |
| Multi-tenancy enforcement | "Every table should have tenant_id, always filter by tenant" (explicit rule in a legacy doc) | Schema has `tenantId` everywhere; **application-layer enforcement does not exist** |
| Frontend-backend integration | Assumed Apollo Client + TanStack Query | 0% implemented in any of the 4 apps |
| Testing | Not explicitly planned in most legacy docs, but implied by "production-grade" language | 0% implemented anywhere |
