# Entity Relationship Diagram

Reflects the actual, already-migrated `prisma/schema.prisma`. This is descriptive (current state), not aspirational.

```mermaid
erDiagram
    TENANT ||--o{ USER : "employs (nullable)"
    TENANT ||--o{ ADVERTISER : owns
    TENANT ||--o{ AFFILIATE : owns
    TENANT ||--o{ OFFER : owns
    TENANT ||--o{ CAMPAIGN : owns
    TENANT ||--o{ TRACKING_LINK : owns
    TENANT ||--o{ CLICK : owns
    TENANT ||--o{ CONVERSION : owns
    TENANT ||--o{ PAYOUT : owns
    TENANT ||--o{ SUBSCRIPTION : has
    TENANT ||--o{ INVOICE : has
    TENANT ||--o{ API_KEY : issues
    TENANT ||--o{ WEBHOOK_ENDPOINT : configures
    TENANT ||--o{ FRAUD_EVENT : logs
    TENANT ||--o{ NOTIFICATION : receives
    TENANT ||--o{ AUDIT_LOG : logs
    TENANT ||--o{ REPORT_SNAPSHOT : has
    TENANT ||--o{ USAGE_COUNTER : tracks

    USER ||--o| ADVERTISER : "may be"
    USER ||--o| AFFILIATE : "may be"
    USER ||--o{ API_KEY : owns
    USER ||--o{ AUDIT_LOG : performs
    USER ||--o{ NOTIFICATION : receives

    ADVERTISER ||--o{ OFFER : provides
    ADVERTISER ||--o{ CLICK : "is destination of"
    ADVERTISER ||--o{ CONVERSION : "is destination of"
    ADVERTISER ||--o{ INVOICE : "is billed via"
    ADVERTISER ||--o{ WEBHOOK_ENDPOINT : receives

    AFFILIATE ||--o{ CAMPAIGN : creates
    AFFILIATE ||--o{ TRACKING_LINK : owns
    AFFILIATE ||--o{ CLICK : generates
    AFFILIATE ||--o{ CONVERSION : earns
    AFFILIATE ||--o{ PAYOUT : requests
    AFFILIATE ||--o{ FRAUD_EVENT : "may trigger"
    AFFILIATE ||--o{ REPORT_SNAPSHOT : "scoped to"

    OFFER ||--o{ CAMPAIGN : "promoted via"
    OFFER ||--o{ TRACKING_LINK : "linked from"
    OFFER ||--o{ CLICK : receives
    OFFER ||--o{ CONVERSION : produces
    OFFER ||--o{ REPORT_SNAPSHOT : "scoped to"

    CAMPAIGN ||--o{ TRACKING_LINK : groups
    CAMPAIGN ||--o{ CLICK : attributes
    CAMPAIGN ||--o{ CONVERSION : attributes

    TRACKING_LINK ||--o{ CLICK : generates

    CLICK ||--o{ CONVERSION : "attributed via clickId"
    CLICK ||--o{ FRAUD_EVENT : "may trigger"

    CONVERSION ||--o{ FRAUD_EVENT : "may trigger"

    SUBSCRIPTION_PLAN ||--o{ SUBSCRIPTION : "subscribed as"
    SUBSCRIPTION ||--o{ INVOICE : generates

    WEBHOOK_ENDPOINT ||--o{ WEBHOOK_DELIVERY : "delivers to"
```

## Key relationship notes

- `User.tenantId` is nullable — this is the mechanism that distinguishes a platform-level user (`tenantId = null`) from a tenant-scoped user (`tenantId` set). See BR-001.
- `Conversion.clickId` is a foreign key to `Click.clickId` (the business-key string), not `Click.id` (the UUID primary key) — this is intentional, since `clickId` is the value that travels externally in the postback URL.
- `Affiliate.userId` is required and unique (one-to-one with `User`); `Advertiser.userId` is optional and unique (an advertiser may or may not have portal access via a linked user).
- No model currently represents a "team" or multiple users per `Advertiser`/`Affiliate` entity — see [`../analysis/target-state.md`](../analysis/target-state.md) for the proposed future sub-team concept.
