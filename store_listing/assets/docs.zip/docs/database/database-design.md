# Database Design — Data Dictionary

Source of truth: `tracking-api/prisma/schema.prisma` (21 models, 28 enums, already migrated via 4 migrations). This document is a structured reference to it — **do not maintain a second, divergent copy of field definitions; update the schema file first, then this summary.**

## Conventions (already followed consistently)
- Primary keys: UUID (`@default(uuid())`).
- Timestamps: `createdAt`/`updatedAt` (`Timestamptz(6)`) on every table.
- Money: `Decimal(18,6)`, never float (BR-011).
- Multi-tenancy: `tenantId` on every tenant-owned table, indexed alongside the most common secondary filter (status, date).
- Soft delete: only `User.isDeleted` currently implements this pattern; no other table has it (see Target State for whether this should be generalized).

## Core Entities

| Table | Purpose | Key fields beyond id/timestamps | Notable constraints |
|---|---|---|---|
| `Tenant` | A client company using the platform | name, slug (unique), domain (unique), status, timezone, currency, trialEndsAt, cacheVersion | `@@index([status])` |
| `User` | Any human account, platform- or tenant-scoped | tenantId (nullable), email/username (unique), password, authProvider, role, isActive, isDeleted, lastLoginAt | `@@index([tenantId, role])`, `@@index([tenantId, isActive])` |
| `Advertiser` | A business buying traffic | tenantId, userId (unique, optional), companyName, postbackSecretHash, allowedIpRanges[], status | `@@unique([tenantId, companyName])` |
| `Affiliate` | A partner generating traffic | tenantId, userId (unique), affiliateCode (unique), balance, reservedBalance, fraudScore, status | `@@index([tenantId, status])`, `@@index([tenantId, fraudScore])` |
| `Offer` | A promotable product/action | tenantId, advertiserId, revenue, payout, conversionType, caps, targeting arrays, status | `@@unique([tenantId, slug])` |
| `Campaign` | An affiliate's organizational grouping of traffic for an offer | tenantId, affiliateId, offerId, sub1-3 | `@@unique([tenantId, affiliateId, offerId, name])` |
| `TrackingLink` | The public, opaque link an affiliate shares | trackingCode (unique), trackingUrl, defaultSub1-3, status | `@@index([tenantId, offerId, affiliateId])` |
| `Click` | One tracked click event | clickId (unique), ip/geo/device fields, sub1-3, status, isFraud, fraudScore | `@@index([tenantId, createdAt])` + 3 more composite indexes |
| `Conversion` | One tracked conversion event | clickId (FK to Click.clickId), transactionId, revenue/payout/profit, status, convertedAt | `@@unique([tenantId, advertiserId, transactionId])` |
| `Payout` | An affiliate payout request/record | affiliateId, amount, status, paymentMethod, requestedAt/approvedAt/paidAt | `@@index([tenantId, status, requestedAt])` |
| `SubscriptionPlan` | A billing tier definition | priceMonthly/Yearly, maxClicks/Conversions/Affiliates/Advertisers/Offers, apiAccess/customDomain/whiteLabel/advancedFraud flags | name/code unique |
| `Subscription` | A tenant's active plan | planId, status, stripeCustomerId/SubscriptionId (unique), currentPeriodStart/End | `@@index([tenantId, status])` |
| `Invoice` | A billing invoice | invoiceNumber (unique), subtotal/tax/total/paidAmount, status | `@@index([tenantId, status])` |
| `ApiKey` | A scoped API credential | keyPrefix, keyHash, scope, allowedIps[], expiresAt | `@@unique([tenantId, keyPrefix])` |
| `WebhookEndpoint` | An advertiser's webhook target | url, secretHash, subscribedEvents[], timeoutMs | `@@index([tenantId, status])` |
| `WebhookDelivery` | One delivery attempt log | eventType, status, attempts, nextRetryAt | `@@index([tenantId, status, createdAt])` |
| `FraudEvent` | One fraud-rule trigger | ruleCode, severity, status, score, reason, details (Json) | `@@index([tenantId, status, severity, createdAt])` |
| `Notification` | One outbound notification | channel, status, title, message, sentAt, readAt | `@@index([tenantId, status, createdAt])` |
| `AuditLog` | One audited action | actorType, actorLabel, action, resourceType/Id, status, ip/userAgent | `@@index([tenantId, createdAt])`, `@@index([resourceType, resourceId])` |
| `ReportSnapshot` | Pre-aggregated reporting bucket | scope, scopeId, bucketStart/End, clicks/conversions/revenue/payout/profit | `@@unique([tenantId, scope, scopeId, bucketStart, bucketEnd])` |
| `UsageCounter` | Metered usage against plan limits | metric, periodStart/End, currentValue, hardLimit, softLimit | `@@unique([tenantId, metric, periodStart, periodEnd])` |

## Enums (28 total) — grouped

- **Identity/access**: `UserRole`, `AuthProvider`, `ApiKeyScope`, `ApiKeyStatus`
- **Tenant/org**: `TenantStatus`, `AdvertiserStatus`, `AffiliateStatus` (no "active" value — only pending/approved/suspended/rejected, a legacy doc's code sample incorrectly assumed one)
- **Offer/campaign**: `OfferStatus`, `ConversionType`, `CampaignStatus`, `TrackingLinkStatus`
- **Tracking**: `ClickStatus` (accepted/filtered/blocked/invalid), `ConversionStatus` (pending/approved/rejected/duplicate/fraud)
- **Money**: `PayoutStatus`, `SubscriptionPlanStatus`, `SubscriptionStatus`, `InvoiceStatus`
- **Integration**: `WebhookStatus`, `WebhookEventType`, `WebhookDeliveryStatus`
- **Fraud**: `FraudSeverity`, `FraudStatus`
- **Comms/audit**: `NotificationChannel`, `NotificationStatus`, `AuditActorType`, `AuditEventStatus`
- **Reporting**: `ReportScope`, `UsageMetric`

## Planned Additions (not yet in schema — require approval, see Open Questions)

| Proposed model/field | Purpose | Why deferred from initial build |
|---|---|---|
| `LedgerEntry` (new model) | Immutable, append-only record of every balance-affecting event (`conversion_credit`, `adjustment`, `payout_debit`, `reversal`) | Money-handling change; needs sign-off (see ADR-006) |
| `Offer.attributionWindowDays` (new field, `Int @default(30)`) | Reject conversions referencing an expired click | Additive, low-risk, but not yet needed until postback module is built |

No other schema changes are indicated — the 21 existing models are well-normalized and already tenant-scoped correctly; see [`erd.md`](erd.md) for relationships.
