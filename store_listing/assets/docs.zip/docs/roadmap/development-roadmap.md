# Development Roadmap

Each phase lists Objective, Modules, Dependencies, Deliverables, Risks, and Definition of Done (DoD). Phases are sequential — do not begin a phase before the prior phase's DoD is met, per the single most-repeated (and least-followed) guidance across all legacy planning documents.

## Phase 0 — Discovery *(this document set)*
- **Objective**: Reconcile 24 contradictory legacy planning documents and the actual codebase into one authoritative plan.
- **Deliverables**: This `docs/` tree, `SOURCE-OF-TRUTH.md`.
- **DoD**: Stakeholder approves the plan (Open Questions answered or explicitly deferred).

## Phase 1 — Foundation & Security Hardening
- **Objective**: Fix the 7 security gaps in security-architecture.md before any new module is built.
- **Modules**: `auth`, `users`, `common` (guards).
- **Dependencies**: None — this must come first.
- **Deliverables**: Global auth guard, `RolesGuard`, tenant-context enforcement mechanism, `tenantId` on JWT, fixed refresh-secret fallback, fixed duration parser, fixed `toUser()`.
- **Risks**: None of the fixes are individually large, but skipping this phase means every subsequent module inherits the same gaps (already observed once with `UsersService.findAll()`).
- **DoD**: An `AFFILIATE`-role token cannot read another tenant's data in any existing query; automated tests exist for each of the 7 gaps.

## Phase 2 — Core Business Entities
- **Objective**: CRUD + approval workflows for the entities everything else depends on.
- **Modules**: `tenants`, `advertisers`, `affiliates`, `offers`, `campaigns`.
- **Dependencies**: Phase 1.
- **Deliverables**: FR-005 through FR-008.
- **Risks**: Low — mostly standard CRUD, but must respect BR-001, BR-007, BR-015 from the start.
- **DoD**: A tenant admin can create an advertiser, approve an affiliate, and publish an offer end-to-end via GraphQL.

## Phase 3 — Tracking Engine *(highest business value, currently 0% built)*
- **Objective**: The click→postback→conversion loop, the single most-repeated "this is the heart of the system" requirement across every legacy document.
- **Modules**: `tracking-links`, `clicks`, `conversions`, `fraud`.
- **Dependencies**: Phase 2 (needs real offers/affiliates to link to).
- **Deliverables**: FR-009 through FR-012.
- **Risks**: Performance risk on the redirect path (<100ms target) — load-test before declaring done. Security risk if postback secret verification (BR-006) is skipped — this is exactly the mistake a legacy code sample made.
- **DoD**: An affiliate can generate a link, a simulated click is logged and redirects in under 100ms, a simulated postback records a conversion exactly once even if retried, and a fraud score is computed.

## Phase 4 — Payments (Manual)
- **Objective**: Let affiliates see earnings and request payout; let finance approve/pay manually.
- **Modules**: `payouts` (+ introduce `LedgerEntry` per ADR-006, though this may land in Phase 4 or immediately after depending on approval timing — see Open Questions #13).
- **Dependencies**: Phase 3 (needs real conversions to generate earnings).
- **Deliverables**: FR-013, FR-014.
- **Risks**: Financial correctness risk — this phase touches real money semantics even at "manual" stage.
- **DoD**: An affiliate's balance accurately reflects approved conversions; a payout request follows the BR-009 state machine without skipping states.

## Phase 5 — Reporting
- **Objective**: Basic live reporting per role.
- **Modules**: `reports`.
- **Dependencies**: Phase 3, Phase 4.
- **Deliverables**: FR-015.
- **DoD**: Each role sees only the data their role-permission-matrix.md entry allows.

## Phase 6 — Frontend Wiring (first dashboard)
- **Objective**: Prove the GraphQL contract end-to-end against a real UI.
- **Modules**: `tracking-super-admin-dashboard` (chosen since it already has the most complete auth UI to replace).
- **Dependencies**: Phases 1–5.
- **Deliverables**: Real Apollo Client wiring, real login, real data replacing mock config files.
- **DoD**: A tenant admin can log in for real and see real (even if sparse) data.

**→ MVP is complete at the end of Phase 6.** See [`../requirements/functional-requirements.md`](../requirements/functional-requirements.md) for the MVP/V1/V2 FR split.

## Phase 7 — V1: Ledger, Queue, Remaining Dashboards
- **Modules**: `LedgerEntry` (if not already done in Phase 4), `subscriptions`, `billing`, `webhooks`, `api-keys`, `notifications`, `audit-logs`; wire the remaining 3 dashboards.
- **Dependencies**: MVP complete.
- **Deliverables**: FR-017 through FR-022.
- **DoD**: Stripe subscription billing works end-to-end for one test tenant; all 4 dashboards are wired to the real backend; brand unification decision (Open Question #3) is implemented.

## Phase 8 — V2: Analytics, Advanced Fraud, Automation
- **Deliverables**: FR-023 through FR-037, ClickHouse migration (per Stage 3 trigger in scalability.md). FR-027 through FR-037 (Smart Links, multi-domain tracking, Two-Way API/offer sync, pixel tracking, MLM commission, automated invoicing, additional payment gateways, configurable alerts, offline conversion import, campaign automation, lifetime/recurring commission) added after the 2026-09-28 competitor (trakaff.com) feature review.

## Phase 9 — Enterprise
- **Deliverables**: White-label, multi-region, self-hosted evaluation, multi-touch attribution — per Open Questions #10, #11.
