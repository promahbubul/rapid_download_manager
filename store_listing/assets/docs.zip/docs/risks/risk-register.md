# Risk Register

| Risk | Category | Impact | Probability | Mitigation |
|---|---|---|---|---|
| Any authenticated user can read cross-tenant data (no RolesGuard/tenant enforcement exists today) | Security | High | Certain (already true today) | Phase 1, TASK-001–004 |
| Forged/unverified postback records fake conversions | Security / Financial | High | Medium once public | BR-006, TASK-015 |
| Mutable-only `Affiliate.balance` cannot be reconciled if a conversion reverses | Financial | High | Medium (will surface the first time a real chargeback happens) | ADR-006, `LedgerEntry` |
| Zero tests anywhere — any fix or new feature risks silent regression | Technical | Medium-High | High while untested code grows | Phase 1 onward: no module ships without tests per testing-strategy.md |
| Two frontend brands (Dicetrack/AffiliatePro) never reconciled | Business / Technical | Medium, growing over time | Certain (already true) | Open Question #3; cheaper to resolve now than after V1 wiring |
| 24 legacy planning documents contain 10 known contradictions; an engineer reading only one could build the wrong thing | Operational | Medium | Was High, now mitigated by this document set | This `docs/` tree + `SOURCE-OF-TRUTH.md` supersede the legacy docs |
| No backup/DR plan exists | Operational | High (data loss) | Low until real tenant data exists, then rises sharply | deployment-architecture.md — daily backup, Phase 1 |
| `/go/{code}` redirect fails to meet <100ms target under real load | Performance | Medium (affiliate experience/reputation) | Unknown — never measured | TASK-014 load test gate |
| Fraud scoring bands (VPN+40 etc.) are copied from legacy docs, never validated against real traffic | Business | Medium (false positives/negatives) | Medium | Open Question #12 — assign policy ownership before V2 tuning |
| No compliance posture defined (GDPR/CCPA) while storing IP/user-agent | Compliance | High if platform enters a regulated market | Unknown — depends on target market (Open Question #1) | Resolve Open Question #1 and #7 before storing real user PII at scale |
| Single deployable/single database is a scaling ceiling past Stage 2 | Scalability | Medium, distant | Low near-term | scalability.md staged plan already anticipates this |
| No CI/CD — deployments and migrations are manual | Operational | Medium (human error risk) | Medium | deployment-architecture.md target CI/CD pipeline |
| Commission precedence rules may be needed sooner than V1 if an early customer demands them | Business | Low-Medium | Unknown | Deferred by design (ADR consistent with anti-overengineering principle); revisit if a real request arrives |
