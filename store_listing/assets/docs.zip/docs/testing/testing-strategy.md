# Testing Strategy

**Current state: zero test files exist anywhere in the backend or any of the 4 frontends.** `jest`, `ts-jest`, `supertest` are already devDependencies in `tracking-api/package.json` but unused.

## Target Strategy by Test Type

| Type | Tool (already available or standard for stack) | Scope |
|---|---|---|
| Unit | Jest (already a devDependency) | Services in isolation — especially `resolveExpiresInSeconds`-style pure logic, fraud scoring calculation, commission calculation (`profit = revenue - payout`) |
| Integration | Jest + a real (test) Postgres instance via Prisma | Service-to-database interactions — e.g. does `createOrUpdateLocalUser` actually enforce uniqueness under concurrent calls (this exact race was found in the code review) |
| API/E2E | Supertest (already a devDependency) against a running Nest app | Full GraphQL mutation/query round-trips, including auth guard behavior — e.g. verify an `AFFILIATE`-role token cannot read another tenant's `users` list once RolesGuard exists |
| Database | Prisma migration tests | Every migration should be tested against a clean DB in CI before merge (no CI exists yet — see deployment-architecture.md) |
| Security | Manual + automated dependency audit (`npm audit`), plus explicit auth-bypass test cases per Gap in security-architecture.md | Confirm each of the 7 listed security gaps has a regression test once fixed, so it cannot silently reappear |
| Performance/Load | k6 or Artillery (not yet chosen) | Specifically the `/go/{code}` redirect path against its <100ms target — this is the one path where a load test is not optional before calling MVP "done" |

## What Must Be Tested Per Module (MVP modules)

- **auth**: registration conflict handling, sign-in failure paths (wrong password, wrong provider, inactive account), Google token verification failure handling, token expiry calculation correctness.
- **users**: tenant-scoped `findAll` (once fixed), role-based access denial.
- **tracking-links / clicks**: click validation order (offer active → affiliate approved → targeting → caps), fallback redirect behavior, click_id uniqueness, <100ms performance budget.
- **conversions**: postback secret rejection, duplicate transactionId rejection, server-side amount computation (never trusting payload amounts), attribution-window rejection once implemented.
- **fraud**: scoring math for each signal combination, band classification boundaries (30/31, 70/71).
- **payouts**: state machine transition enforcement (BR-009) — a test asserting `paid → requested` is rejected, for example.

## Testing Gate for This Plan Itself

No code should be merged for any MVP module without accompanying tests covering at minimum the "Main flow," "Alternative flow," and "Failure cases" documented for its corresponding FR in [`../requirements/functional-requirements.md`](../requirements/functional-requirements.md). This is a process rule, not a technical one — but it directly addresses the risk noted in the Risk Register: "zero tests anywhere means any fix risks silent regression."
