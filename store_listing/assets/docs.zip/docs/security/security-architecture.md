# Security Architecture

## Current Gaps (must fix before building new modules — Phase 1 of the roadmap)

| # | Gap | Risk | Fix |
|---|---|---|---|
| 1 | No global default-deny auth guard — only `GqlThrottlerGuard` is a global `APP_GUARD`; `GqlJwtAuthGuard` is opt-in per resolver | Any new query/mutation is public by default unless the author remembers to guard it | Register a global auth guard with an explicit `@Public()` opt-out |
| 2 | No `RolesGuard`/`@Roles()` anywhere | Any authenticated user (including the lowest-privileged `AFFILIATE`) can call any guarded query, e.g. `users` returns every user across every tenant | Add `RolesGuard` + decorator; apply per role-permission-matrix.md |
| 3 | JWT/`AuthenticatedUser` does not carry `tenantId` | No request-scoped signal exists for enforcing tenant isolation at all | Add `tenantId` to JWT claims and `AuthenticatedUser` interface |
| 4 | No tenant-scoping enforcement mechanism — `UsersService.findAll()` has zero tenant filter | Cross-tenant data leakage the moment any new module is built by copying this pattern | Prisma Client Extension or `AsyncLocalStorage` request context enforcing `tenantId` on every query |
| 5 | `refreshTokenSecret` falls back silently to `jwtSecret` if `JWT_REFRESH_SECRET` is unset, and `env.validation.ts` doesn't require it | Access and refresh tokens end up signed with the same key in a misconfigured deployment, with no warning | Add `JWT_REFRESH_SECRET` to required env keys |
| 6 | `resolveExpiresInSeconds` mis-parses any duration string without an `h`/`d`/`m` suffix | Reported token expiry can be wrong by 60x for certain config values | Use the `ms` library instead of a hand-rolled parser |
| 7 | `toUser()` nulls out real `tenantId`/`firstName`/`lastName`/`phone`/`lastLoginAt` on every read | Silent data loss on every API response; breaks tenant scoping entirely at the data layer | Remove the hardcoded nulls; map real column values |

## Authentication

- JWT access token (short-lived, e.g. 15m) + refresh token (longer-lived, e.g. 30d), already implemented via `@nestjs/jwt` + Passport.
- Password hashing: bcrypt, cost factor 12 (already implemented) — see ADR-007 for why this is retained over argon2.
- Google Sign-In via `google-auth-library`, ID token verification against configured client IDs (already implemented).
- MFA: not currently implemented; recommended for `TENANT_ADMIN`/`PLATFORM_OWNER` roles in V1, not MVP-blocking.

## Authorization

- Model: RBAC (role-based), scoped by tenant (see [`../business/role-permission-matrix.md`](../business/role-permission-matrix.md)). ABAC (attribute-based) is not required at current complexity — e.g. "Manager can only see assigned affiliates" is a row-level ownership check, not a full ABAC policy engine.
- Enforcement point: NestJS guards + a query-level tenant filter (Gap #4 above), not just UI-level hiding.

## API/Postback Security

- Postback secret: `Advertiser.postbackSecretHash` (already a schema field) — verified via HMAC signature or bearer secret over HTTPS, never a plain unauthenticated query parameter (BR-006). **A legacy planning document's only code sample skips this check entirely — it must never be used as a template.**
- Optional defense-in-depth: `Advertiser.allowedIpRanges` (already a schema field) as an IP allowlist.
- API keys (`ApiKey` model, V1): scoped (`ApiKeyScope`: admin/dashboard/tracking/postback/reporting/webhook), hashed at rest (`keyHash`), optional IP allowlist (`allowedIps`).
- Webhook signatures: outbound webhooks to advertisers (`WebhookEndpoint.secretHash`, V1) must be HMAC-signed so the advertiser can verify authenticity.

## Standard Web Security Checklist

| Control | Status |
|---|---|
| Helmet | Implemented |
| CORS allowlist | Implemented (configurable via `app.corsOrigins`) — note: has a known bug where an empty resolved list silently blocks all origins instead of falling back to allow-all (see current-state.md) |
| Rate limiting | Implemented globally via `@nestjs/throttler` |
| Input validation | Implemented via `class-validator`/`class-transformer`, global `ValidationPipe` with `whitelist`+`forbidNonWhitelisted` |
| CSRF | GraphQL over POST with JWT bearer auth is inherently less CSRF-exposed than cookie-session auth; no additional CSRF token currently implemented — acceptable given the auth model, revisit if cookie-based sessions are ever introduced |
| XSS | Frontend responsibility (React escapes by default); backend never reflects raw user input into HTML |
| SQL injection | Prisma parameterizes all queries — not a current risk surface |
| File upload security | N/A — no file upload feature exists in any current FR |
| Secrets management | `.env.local`/`.env.prod` via `dotenv`, never committed (per `.gitignore`); no secrets manager (Vault/AWS Secrets Manager) yet — acceptable at current scale, revisit at V1 |
| Encryption in transit | HTTPS via Cloudflare/reverse proxy (not yet configured in this repo — see deployment-architecture.md) |
| Encryption at rest | Not implemented for any field; `Advertiser.postbackSecretHash`/`ApiKey.keyHash`/passwords are hashed (not reversible), which is the correct control for those fields — no additional at-rest encryption is currently required by any stated compliance need (Open Question #7) |
| Audit logging | `AuditLog` model exists but nothing writes to it yet (BR-012) |

## Threat Model

| Threat | Impact | Likelihood | Mitigation |
|---|---|---|---|
| Cross-tenant data read (any authenticated user reads another tenant's data) | High — breaks the core multi-tenant promise, could end the business relationship with an affected tenant | **Currently certain** — no enforcement exists at all | Gaps #2–#4 above |
| Forged postback (attacker fabricates a conversion without a real click) | High — direct financial loss (fake commission payouts) | Medium, once the tracking API is public | BR-006, mandatory secret verification |
| Advertiser-dictated payout amount | High — advertiser could underpay or an attacker could overpay themselves | Low if BR-005 is followed; a legacy doc shows exactly this mistake once | Server-side computation only, never trust postback payload for amounts |
| Click fraud (bot/VPN inflating affiliate earnings) | Medium — financial loss, distorted reporting | High once real traffic exists | Fraud scoring engine (FR-012), rate limiting on `/go/{code}` |
| Replay of a valid postback (advertiser or attacker resends the same conversion) | Medium — double-counted revenue/payout | Medium | Idempotency via `(tenantId, advertiserId, transactionId)` uniqueness (already in schema) |
| JWT theft (XSS or token leakage) | High — full account takeover | Low with current React/Apollo patterns, but no MFA increases blast radius | Standard XSS hygiene (frontend), short access-token TTL, MFA recommended V1 |
| Refresh-token/access-token key confusion (Gap #5) | Medium — weakens token-type separation | **Currently possible in misconfigured environments** | Fix #5 above |
| Rate-limit bypass via shared fallback IP bucket (`GqlThrottlerGuard`'s `127.0.0.1` fallback when `req`/`res` are missing) | Low-medium — legitimate users could be throttled together | Low, edge case (subscriptions/custom context) | Audit `getRequestResponse` fallback path when building V1 subscriptions support |

See [`../analysis/current-state.md`](../analysis/current-state.md) for the full list of already-identified code-level bugs this section summarizes at the architecture level.
