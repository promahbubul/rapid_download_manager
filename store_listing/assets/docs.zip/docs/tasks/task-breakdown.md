# Task Breakdown

Ordered by dependency. Covers Phase 1–3 (the MVP-critical path) at full detail; Phase 4–6 tasks are listed at summary level since their design depends on decisions made while executing earlier tasks.

## Phase 1 — Foundation & Security

**TASK-001** — Add global default-deny authentication guard
- Description: Register a global `APP_GUARD` for JWT authentication; add an `@Public()` decorator for the few endpoints that must remain open (e.g. `registerLocal`, `signInLocal`).
- Dependencies: None.
- Files affected: `src/app.module.ts`, new `@Public()` decorator in `src/common/decorators/`.
- Acceptance criteria: A newly-added, unguarded resolver method rejects unauthenticated requests by default.
- Testing: Integration test hitting a new dummy resolver without a token → expect 401.
- DoD: All existing resolvers still work for authenticated users; `registerLocal`/`signInLocal`/`signInWithGoogle` still work unauthenticated.

**TASK-002** — Implement `RolesGuard` and `@Roles()` decorator
- Dependencies: TASK-001.
- Files affected: new `src/common/guards/roles.guard.ts`, new `src/common/decorators/roles.decorator.ts`.
- Acceptance criteria: A resolver annotated `@Roles(UserRole.SUPER_ADMIN)` rejects a request from an `AFFILIATE`-role token with `FORBIDDEN`.
- Testing: Unit test on the guard's `canActivate` logic; integration test per role combination.
- DoD: Guard is reusable and does not require per-module boilerplate beyond the decorator.

**TASK-003** — Add `tenantId` to JWT claims and `AuthenticatedUser`
- Dependencies: None (can run parallel to TASK-001/002).
- Files affected: `src/modules/auth/auth.service.ts` (`createAuthPayload`), `src/modules/auth/interfaces/authenticated-user.interface.ts`, `src/modules/auth/strategies/jwt.strategy.ts`.
- Acceptance criteria: A decoded JWT contains `tenantId`; `req.user.tenantId` is populated in every guarded resolver.
- Testing: Unit test asserting the signed JWT payload includes `tenantId` (including `null` for platform-level users).
- DoD: No existing auth flow (local, Google) regresses.

**TASK-004** — Implement tenant-context enforcement mechanism
- Dependencies: TASK-003.
- Files affected: new `src/database/tenant-context.ts` (AsyncLocalStorage) or a Prisma Client Extension in `src/database/prisma.service.ts`.
- Acceptance criteria: A query issued without an explicit tenant filter still only returns rows for the current request's `tenantId`, except for platform-level roles making an explicit cross-tenant call.
- Testing: Integration test — two tenants' data seeded, a tenant-scoped user's query never returns the other tenant's rows even if the service code "forgets" to filter.
- DoD: `UsersService.findAll()` is refactored to use this mechanism (fixing the known bug) as the first real consumer.

**TASK-005** — Fix `toUser()` field-nulling bug
- Dependencies: None.
- Files affected: `src/modules/users/users.service.ts`.
- Acceptance criteria: `tenantId`, `firstName`, `lastName`, `phone`, `lastLoginAt` reflect real database values in every response.
- Testing: Unit test seeding a user with all these fields populated, asserting `toUser()` returns them unchanged.

**TASK-006** — Fix refresh-token secret fallback
- Dependencies: None.
- Files affected: `src/config/auth.config.ts`, `src/config/env.validation.ts` (add `JWT_REFRESH_SECRET` to `REQUIRED_KEYS`).
- Acceptance criteria: App fails to start if `JWT_REFRESH_SECRET` is unset — no silent fallback.
- Testing: Unit test on `validateEnv` asserting missing `JWT_REFRESH_SECRET` throws.

**TASK-007** — Fix `resolveExpiresInSeconds` duration parsing
- Dependencies: None.
- Files affected: `src/modules/auth/auth.service.ts` — replace hand-rolled parser with the `ms` package.
- Acceptance criteria: `"3600"` (bare seconds), `"30s"`, `"15m"`, `"2h"`, `"7d"` all resolve to the mathematically correct number of seconds.
- Testing: Unit test table covering each unit suffix plus the bare-number case.

## Phase 2 — Core Business Entities

**TASK-008** — Tenant module: create/read/update (no delete — tenants are suspended, not deleted)
- Dependencies: TASK-001–004.
- Acceptance criteria: FR-005 main flow works; a `PLATFORM_OWNER` token can create a tenant, a `TENANT_ADMIN` cannot.

**TASK-009** — Advertiser module: CRUD + postback secret generation
- Dependencies: TASK-008.
- Acceptance criteria: FR-006; `postbackSecretHash` is generated and hashed at creation, never returned in plaintext after initial creation response.

**TASK-010** — Affiliate module: application + approval workflow
- Dependencies: TASK-008.
- Acceptance criteria: FR-007; BR-007 enforced (only `approved` affiliates can later create tracking links — cross-checked in Phase 3, not enforceable yet in isolation).

**TASK-011** — Offer module: CRUD with targeting/caps fields
- Dependencies: TASK-009.
- Acceptance criteria: FR-008; BR-015 warning surfaced (not hard-blocked, per Open Question #14) when `payout > revenue`.

**TASK-012** — Campaign module: CRUD, scoped to an affiliate+offer
- Dependencies: TASK-010, TASK-011.

## Phase 3 — Tracking Engine

**TASK-013** — Tracking Link generation
- Dependencies: TASK-010, TASK-011.
- Acceptance criteria: FR-009; generated `trackingCode` is unguessable (sufficient entropy), unique (relies on existing DB constraint).

**TASK-014** — `/go/{trackingCode}` REST endpoint
- Dependencies: TASK-013.
- Acceptance criteria: FR-010 main + alternative flows; measured redirect latency <100ms under a basic load test.
- Testing: Performance test (k6/Artillery) — this task is not "done" without a latency measurement, not just functional correctness.

**TASK-015** — `/postback` REST endpoint
- Dependencies: TASK-014.
- Acceptance criteria: FR-011 main + alternative (duplicate) + failure (invalid secret, click not found) flows; BR-004, BR-005, BR-006 all independently testable and tested.
- Testing: Explicit test simulating a duplicate `transactionId` submission and asserting only one `Conversion` row exists.

**TASK-016** — Fraud scoring engine
- Dependencies: TASK-015.
- Acceptance criteria: FR-012; scoring math matches the documented signal weights exactly; `FraudEvent` rows are created with correct `ruleCode`/`severity`.

## Phase 4+ (summary — detailed tasks to be broken down when this phase begins)

- `LedgerEntry` model + migration (depends on Open Question #13 approval).
- Payout request/approve/pay workflow (depends on ledger).
- Reporting queries (depends on Phase 3 data existing).
- First dashboard Apollo wiring (depends on Phase 1–5 GraphQL surface being stable).
