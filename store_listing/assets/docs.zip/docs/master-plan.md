# DiceTrak — Master Plan (Missing / Fixed Items)

As of: 2026-09-29

## Scope

This plan has two parts:

1. **platform_owner_dashboard** — every issue/gap found across three full code-review rounds this session, all fixed and pushed to `main`.
2. **The other 4 dashboards** (super_admin, advertiser, affiliate, user) — gaps found while researching them for the User Guide; **not fixed yet**.

## platform_owner_dashboard — issues found (all fixed)

| File | What was missing / wrong | Status |
| --- | --- | --- |
| `src/components/dashboard/nav-link.tsx`, `nav-link-group.tsx` | Sidebar active color was a hardcoded hex (`#45A247`), not theme-aware | ✅ Fixed — uses `brand-end` token |
| `src/components/form/switch-field.tsx` | Old bordered-box look had crept back in (Input/Select already had it removed) | ✅ Fixed |
| `src/components/settings/settings-tabs.tsx` | Role-gating incomplete — only the Save button was hidden for Platform Support, fields stayed editable | ✅ Fixed — fields disabled |
| `src/components/dashboard/stat-card.tsx`, `requires-attention-card.tsx` | `cursor-pointer` shown but clicking did nothing | ✅ Fixed — wired up real links |
| `src/components/dashboard/nav-link-group.tsx` (whole file) | Became dead code after Settings was merged into tabs | ✅ Removed |
| `src/config/dashboard-data.ts` | Overview's Pending Approvals / Fraud Escalations counts didn't match the actual mock data | ✅ Fixed |
| `src/components/tenants/add-organization-dialog.tsx` | Plus icon size inconsistent with other Add buttons | ✅ Fixed |
| `src/components/ui/checkbox.tsx`, `accordion.tsx`, `image-dropzone.tsx`, `rich-text-editor.tsx`, `pagination.tsx`, `dropdown-menu.tsx` | Never imported anywhere — dead code | ✅ Removed |
| `src/components/form/copyable-field.tsx`, `phone-field.tsx`, `rich-text-field.tsx`, `tags-input.tsx`, `toggle-row-field.tsx`, `required-mark.tsx` | Never imported anywhere — dead code | ✅ Removed |
| `src/hooks/use-row-selection.ts` | Never used — dead code | ✅ Removed |
| `src/config/countries.ts` | Never used — dead code | ✅ Removed |
| `src/lib/nav-active.ts` | Became fully unused once nav-link-group.tsx was removed | ✅ Removed |
| `src/components/dashboard/coming-soon.tsx` | Never imported anywhere — dead code | ✅ Removed |
| `src/app/globals.css` | `scrollbar-brand` utility (dead, hardcoded hex) and `react-phone-number-input` CSS (orphaned) | ✅ Removed |
| `package.json` | 7 `@tiptap/*` packages + `react-phone-number-input` — unused dependencies | ✅ Uninstalled |
| `src/components/reports/reports-tabs.tsx` | Missing "no results" empty state (every other table had one) | ✅ Fixed |
| `src/app/dashboard/organizations/[id]/page.tsx` | Page didn't exist — organization name/View link 404'd | ✅ Created |
| `src/components/plans/add-plan-dialog.tsx` | Missing "Max Offers" field (present in the type and on the Plans page display) | ✅ Fixed |
| `src/components/ui/button.tsx` | Gradient button corner seam, then a follow-up fix accidentally clipped the keyboard focus ring | ✅ Fixed (two iterations) |
| `src/components/dashboard/header.tsx`, `user-profile.tsx`, `notification-bell.tsx` (new) | No logout option, notification bell was non-functional, unnecessary Help icon | ✅ Fixed / added |
| `src/components/dashboard/stat-card.tsx`, `requires-attention-card.tsx`, `organizations/[id]/page.tsx` | Mobile overflow — forced `grid-cols-2` too cramped on small phones | ✅ Fixed |
| `src/components/dashboard/sidebar-context.tsx`, `sidebar.tsx`, `sidebar-content.tsx`, `dashboard-shell.tsx` (new) | No sidebar collapse (icon-only / icon+text) feature | ✅ Added (new feature, not a bug) |

## Other 4 dashboards — not yet built / incomplete (research only, not fixed)

| Project | File | What's missing |
| --- | --- | --- |
| user_dashboard | `src/app/dashboard/offers/add/page.tsx` | Renders only a ComingSoon placeholder — "Add Offer" page not built |
| affiliate_dashboard | `src/app/dashboard/[...slug]/page.tsx` (catch-all) | Tracking Links, Statistics, Creatives, Referrals — linked from Overview's Quick Links but no real page exists; shows generic "Coming Soon" |
| advertiser_dashboard | `docs/business/role-permission-matrix.md` vs UI | Docs say Advertiser should have only request/own-scope access to Offers, but the UI implements full Campaign CRUD — doc/UI mismatch |
| super_admin_dashboard | — | No major gap found during research; every nav item has a page |

*Note: this second table came from research only, not a full line-by-line review like platform_owner_dashboard got.*

## The one big thing missing everywhere

All 5 dashboards are still **frontend-only** — mock/static data, no real backend/API connection, no real authentication. The shared `api` project (NestJS + Prisma/PostgreSQL) exists but needs its own database running locally to start (`DATABASE_URL` in `api/.env.local` points to `localhost:5435`, which isn't running).
