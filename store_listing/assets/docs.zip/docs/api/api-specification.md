# API Specification

## Split Decision (confirmed, resolves a legacy contradiction)

- **REST** — `/go/{trackingCode}` (click/redirect) and `/postback` (conversion) — public-facing, unauthenticated-by-JWT (authenticated by secret/signature instead), optimized for latency.
- **GraphQL** — everything dashboard-facing — authenticated via JWT, role- and tenant-scoped, optimized for flexible querying.

No endpoint should be designed outside this split without a documented ADR.

## REST — Tracking & Postback (MVP)

### `GET /go/{trackingCode}`
- **Purpose**: Resolve a tracking link and redirect the visitor, logging a `Click`.
- **Auth**: None (public) — protected by unguessable `trackingCode`, not credentials.
- **Path param**: `trackingCode` (string, opaque).
- **Query params (optional)**: `sub1`, `sub2`, `sub3` (override `TrackingLink.defaultSub1-3`).
- **Response**: `302 Found` with `Location` header (either `Offer.landingUrl?click_id=...` or `Offer.fallbackUrl`). No JSON body.
- **Errors**: Unknown code / inactive offer or affiliate / tenant not active → `302` to a generic "unavailable" page — never a raw 4xx/5xx to the visitor.
- **Rate limiting**: Per-IP throttle to blunt click-flooding (`@nestjs/throttler`, already a dependency).
- **Business rules**: FR-010, BR-007, BR-008.

### `POST /postback`
- **Purpose**: Record a conversion.
- **Auth**: Secret/signature tied to `Advertiser.postbackSecretHash` (header or signed body — implementation detail for the building engineer, but must not be a plain unguarded query param per BR-006). Optional additional check against `Advertiser.allowedIpRanges`.
- **Body**: `{ clickId: string, transactionId: string, status?: string, metadata?: object }` — **never** `payout`/`revenue` (BR-005).
- **Response `200`**: `{ success: true, status: "APPROVED" | "PENDING", conversionId: string }`.
- **Response `200` (duplicate)**: `{ success: false, status: "DUPLICATE", message: "Conversion already recorded" }` — not an error status code, to avoid advertiser retry storms.
- **Errors**: `401`/`403` invalid secret. `404` click not found or outside attribution window.
- **Idempotency**: Enforced via `@@unique([tenantId, advertiserId, transactionId])` — already in schema.
- **Business rules**: FR-011, BR-004, BR-005, BR-006, BR-011.

## GraphQL — Dashboard (existing + planned)

### Existing (implemented)
```graphql
mutation registerLocal(input: RegisterLocalInput!): AuthPayload
mutation signInLocal(input: SignInInput!): AuthPayload
mutation signInWithGoogle(input: GoogleSignInInput!): AuthPayload
query me: User                      # NOTE: currently non-null-typed but can crash on deleted user — see current-state.md
query users: [User!]!               # NOTE: currently has no role/tenant restriction — critical bug, see security-architecture.md
```

### Planned (MVP, not yet implemented)
```graphql
# Advertiser
mutation createAdvertiser(input: CreateAdvertiserInput!): Advertiser
query advertisers(filter: AdvertiserFilter, cursor: String, limit: Int): AdvertiserConnection!
mutation updateAdvertiser(id: ID!, input: UpdateAdvertiserInput!): Advertiser

# Affiliate
mutation applyAsAffiliate(input: AffiliateApplicationInput!): Affiliate
mutation approveAffiliate(id: ID!): Affiliate
mutation suspendAffiliate(id: ID!, reason: String!): Affiliate
query affiliates(filter: AffiliateFilter, cursor: String, limit: Int): AffiliateConnection!

# Offer
mutation createOffer(input: CreateOfferInput!): Offer
mutation updateOffer(id: ID!, input: UpdateOfferInput!): Offer
query offers(filter: OfferFilter, cursor: String, limit: Int): OfferConnection!
query offer(id: ID!): Offer

# Tracking Link
mutation createTrackingLink(offerId: ID!, campaignId: ID): TrackingLink
query myTrackingLinks(cursor: String, limit: Int): TrackingLinkConnection!

# Payout
mutation requestPayout(amount: Decimal!, paymentMethod: String!): Payout
mutation approvePayout(id: ID!): Payout
mutation markPayoutPaid(id: ID!, paymentReference: String): Payout
query payouts(filter: PayoutFilter, cursor: String, limit: Int): PayoutConnection!

# Reporting
query report(scope: ReportScope!, scopeId: ID, dateRange: DateRangeInput!): ReportResult!
```

## Pagination Standard

**All list queries returning potentially-large or growing collections (Click, Conversion, AuditLog, and any reporting-adjacent list) MUST use cursor-based (Relay-style Connection) pagination** — `edges { node, cursor } pageInfo { hasNextPage, endCursor }` — not offset/limit. Bounded, small collections (Offer, Advertiser, Affiliate, SubscriptionPlan — thousands of rows at most) may use simple offset/limit for UI page-number display, since keyset pagination's complexity isn't justified there. This mirrors the reasoning already agreed in prior session discussion and avoids the exact class of pagination bug found across all 4 existing mock dashboards (fixed-window page buttons that don't track the real current page).

## Error Response Convention

- GraphQL: standard Apollo error extensions with a stable `code` (e.g. `UNAUTHENTICATED`, `FORBIDDEN`, `TENANT_MISMATCH`, `VALIDATION_ERROR`) — never leak raw stack traces or DB errors (already partially true via `includeStacktraceInErrorResponses: !isProduction`, but must be audited once more resolvers exist).
- REST: standard HTTP status codes; body `{ success: false, code: string, message: string }`.

## Rate Limiting

- `/go/{code}`: per-IP, generous (visitors, not attackers, dominate traffic) — tune once real data exists.
- `/postback`: per-advertiser (via the resolved `Advertiser.id`, not just IP, since advertiser servers may share IPs/load balancers).
- GraphQL mutations: per-user, standard `@nestjs/throttler` (already applied globally via `GqlThrottlerGuard`).
