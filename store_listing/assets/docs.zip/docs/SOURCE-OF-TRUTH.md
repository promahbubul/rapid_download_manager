# SOURCE OF TRUTH

This document, together with the approved documents it links to under `docs/`, is the primary reference for any future implementation work (human or AI agent) on this system. Where this tree conflicts with the 24 legacy planning documents under `tracking-api/docs/` or with `tracking-api/docs/MASTER_PRODUCT_ARCHITECTURE_PLAN.md`, **this tree wins** — it was produced by reconciling all of them against the actual codebase.

## 1. Business Vision

TrakAff is a multi-tenant Performance Marketing Infrastructure SaaS. Client companies ("Tenants") run their own affiliate/partner programs on the platform; TrakAff provides tracking, attribution, fraud signal, commission calculation, and reporting — not ownership of the advertiser/affiliate relationship itself. See [`business/business-model.md`](business/business-model.md).

## 2. Core Requirements

MVP is the single Offer → TrackingLink → Click → Postback → Conversion → Manual Payout → Report loop, currently 0% implemented. See [`requirements/functional-requirements.md`](requirements/functional-requirements.md) and [`roadmap/development-roadmap.md`](roadmap/development-roadmap.md).

## 3. Architecture

Modular monolith (ADR-001), REST for tracking/postback + GraphQL for dashboard (ADR-002), shared-database multi-tenancy via `tenantId` (ADR-003). See [`architecture/system-architecture.md`](architecture/system-architecture.md).

## 4. Database Principles

`prisma/schema.prisma` (21 models) is the single source of truth for data structure — this tree documents it, never duplicates or overrides it. All money is `Decimal(18,6)`. Every tenant-owned table carries `tenantId`. See [`database/database-design.md`](database/database-design.md).

## 5. API Principles

Opaque `trackingCode` in public URLs, never raw entity IDs (ADR-008). Server-side-only computation of money amounts (BR-005). Cursor-based pagination for high-volume lists. See [`api/api-specification.md`](api/api-specification.md).

## 6. Security Principles

Default-deny authentication, explicit role + tenant authorization on every operation, mandatory postback secret verification, no money amount ever trusted from an external caller. See [`security/security-architecture.md`](security/security-architecture.md).

## 7. Coding Constraints

- No new top-level backend module without updating this tree first.
- No schema change without updating [`database/database-design.md`](database/database-design.md) and, if it affects money handling, an ADR.
- No module ships without tests per [`testing/testing-strategy.md`](testing/testing-strategy.md).
- Do not adopt Kubernetes, Kafka, Rust, ClickHouse, or microservices without a documented ADR justifying the specific measured need (see ADR-001, ADR-004, ADR-005).

## 8. Important Business Rules

See [`business/business-rules.md`](business/business-rules.md) (BR-001 through BR-016). The most consequential: BR-001 (tenant scoping), BR-005/BR-006 (postback trust boundary), BR-009 (payout state machine), BR-011 (money precision).

## 9. Architectural Decisions

See [`decisions/adr-log.md`](decisions/adr-log.md) (ADR-001 through ADR-008).

## 10. Current Project Status

Database is production-grade and complete. Only `auth` and `users` backend modules are implemented. All 4 frontend dashboards are static mock UIs with zero backend connectivity. Zero tests, zero CI/CD, zero infrastructure-as-code exist. See [`analysis/current-state.md`](analysis/current-state.md) for full detail and [`analysis/target-state.md`](analysis/target-state.md) for what "done" looks like.

## 11. Future Roadmap

Phase 0 (this document set, done) → Phase 1 Foundation/Security → Phase 2 Core Entities → Phase 3 Tracking Engine → Phase 4 Payments → Phase 5 Reporting → Phase 6 Frontend Wiring (**= MVP complete**) → Phase 7 V1 (ledger, queue, billing, remaining dashboards) → Phase 8 V2 (analytics, advanced fraud, automation) → Phase 9 Enterprise. See [`roadmap/development-roadmap.md`](roadmap/development-roadmap.md) and [`tasks/task-breakdown.md`](tasks/task-breakdown.md) for TASK-001 onward.

---

## Full Document Index

```text
docs/
├── SOURCE-OF-TRUTH.md              (this file)
├── business/
│   ├── business-model.md
│   ├── business-rules.md           (BR-001..BR-016)
│   ├── stakeholders.md
│   ├── role-permission-matrix.md
│   └── open-questions.md           (15 unresolved questions — read before assuming anything)
├── requirements/
│   ├── functional-requirements.md  (FR-001..FR-026)
│   └── non-functional-requirements.md
├── architecture/
│   ├── system-architecture.md
│   ├── backend-architecture.md
│   ├── frontend-architecture.md
│   └── scalability.md
├── database/
│   ├── database-design.md
│   └── erd.md
├── api/
│   └── api-specification.md
├── security/
│   └── security-architecture.md
├── testing/
│   └── testing-strategy.md
├── deployment/
│   └── deployment-architecture.md
├── decisions/
│   └── adr-log.md                  (ADR-001..ADR-008)
├── roadmap/
│   └── development-roadmap.md
├── tasks/
│   └── task-breakdown.md           (TASK-001..TASK-016 detailed, Phase 4+ summarized)
├── risks/
│   └── risk-register.md
└── analysis/
    ├── current-state.md
    └── target-state.md
```

## Change Control

If a future requirement conflicts with anything decided in this tree, do not silently change the architecture. Document a Change Request with: affected requirements → affected architecture → affected database → affected APIs → affected tasks → risks → recommendation. Wait for explicit approval before implementation, exactly as this entire planning exercise itself required approval before any code would be touched.

## Approval Gate

**No implementation work should begin until:**
1. All 15 items in [`business/open-questions.md`](business/open-questions.md) are answered or explicitly deferred with an owner.
2. This document set is reviewed and approved.

Only after that does Phase 1 (Foundation & Security Hardening, [`tasks/task-breakdown.md`](tasks/task-breakdown.md) TASK-001) become authorized to start.
