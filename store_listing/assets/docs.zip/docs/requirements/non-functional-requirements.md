# Non-Functional Requirements

| Category | Target | Status |
|---|---|---|
| **Performance** — tracking redirect | < 100ms server-side processing time | Not measured (endpoint doesn't exist yet) |
| **Performance** — dashboard queries | < 1s p95 for GraphQL queries | Not measured |
| **Performance** — reporting | May be asynchronous/pre-aggregated (`ReportSnapshot`); no hard real-time requirement | Not implemented |
| **Scalability** | Staged: 10K → 1M → 10M → 100M+ events/day, see [`../architecture/scalability.md`](../architecture/scalability.md) | Stage 1 (current: ~0 events/day in production) |
| **Availability** | Target 99.9% once in production (no SLA committed pre-launch); competitor (trakaff.com) advertises 99.99% as a stretch benchmark, not yet adopted as this project's own target | N/A — not in production |
| **Security** | See [`../security/security-architecture.md`](../security/security-architecture.md) | Multiple known gaps (no RolesGuard, no tenant enforcement) |
| **Compliance** | GDPR (data export/erasure requests, consent tracking) — added after competitor review, no design work done yet | Not implemented — Open Question, not yet scheduled to a phase |
| **Reliability** | Postback processing must be idempotent (BR-004); no conversion double-counted on retry | Not implemented |
| **Maintainability** | Modular monolith with clear module boundaries (already followed in folder structure); ADRs required for architecture-level decisions | Followed for module structure; 0 ADRs existed before this document |
| **Observability** | Sentry + structured logging from Day 1 of MVP | Not implemented — no error tracking or structured logging exists |
| **Accessibility** | WCAG 2.1 AA target for all 4 dashboards | Not assessed; no accessibility audit has been done |
| **Internationalization** | `Tenant.timezone`/`Tenant.currency` exist; no UI translation/locale system | Not implemented — single-language (English) UI only |
| **Backup** | Daily PostgreSQL backup, retained per data-retention policy (Open Question #6) | Not implemented — no backup automation exists |
| **Disaster Recovery** | Not yet defined — no RPO/RTO target set | Open Question |

Numbers above (100ms, 1s, 99.9%) are carried forward from the legacy planning documents' consistent recommendations, not independently re-derived — they should be validated against real traffic once the MVP tracking engine exists.
