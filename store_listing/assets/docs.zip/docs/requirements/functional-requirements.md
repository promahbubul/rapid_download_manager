# Functional Requirements

Format per requirement: Purpose · Actor · Preconditions · Main flow · Alternative/failure flow · Business rules · Expected result. MVP-critical requirements (FR-001 to FR-016) are documented in full; V1/V2 requirements (FR-017+) are documented at summary level since they are not yet in scope — see [`../roadmap/development-roadmap.md`](../roadmap/development-roadmap.md).

---

### FR-001 — Local Registration
- **Purpose**: Let a new user create a local (email/password) account.
- **Actor**: Any unauthenticated visitor.
- **Preconditions**: Email not already registered.
- **Main flow**: Submit email/username/password → validate → hash password (bcrypt) → create `User` row → issue access+refresh JWT.
- **Failure**: Email exists → `ConflictException`. Weak password → validation error before any DB write.
- **Business rules**: BR-011 (n/a here), password ≥ 8 chars with letters+numbers (existing DTO rule).
- **Expected result**: New `User` row, `AuthPayload` returned. *(Implemented — see current-state.md)*

### FR-002 — Local Sign-In
- **Purpose**: Authenticate an existing local user.
- **Actor**: Registered user.
- **Main flow**: Submit email/password → verify hash → issue tokens.
- **Failure**: Wrong credentials, wrong provider, inactive/deleted account → `UnauthorizedException` (generic message, no user enumeration).
- **Expected result**: `AuthPayload`. *(Implemented)*

### FR-003 — Google Sign-In
- **Purpose**: Authenticate/register via Google ID token.
- **Actor**: Any visitor with a Google account.
- **Main flow**: Verify ID token against configured client IDs → find-or-create `User` → issue tokens.
- **Failure**: Invalid/expired token, Google auth not configured → error (currently leaks as a raw 500 — see current-state.md gap).
- **Expected result**: `AuthPayload`. *(Implemented, with known bugs)*

### FR-004 — Token Refresh
- **Purpose**: Exchange a valid refresh token for a new access token.
- **Actor**: Authenticated client holding a refresh token.
- **Status**: Not yet implemented as a distinct mutation (refresh secret exists in config only).

### FR-005 — Tenant Onboarding
- **Purpose**: Create a new client company (`Tenant`) and its first `TENANT_ADMIN` user.
- **Actor**: Platform Owner (or a self-serve signup flow — undecided, see Open Questions).
- **Main flow**: Create `Tenant` (status=trial) → create first `User` with `tenantId` set and admin role → send welcome notification.
- **Business rules**: BR-001.
- **Status**: Not implemented (module stub only).

### FR-006 — Advertiser Management
- **Purpose**: CRUD + approval workflow for advertiser accounts within a tenant.
- **Actor**: Tenant Admin, Manager (read/update).
- **Main flow**: Create advertiser (company info, contact, postback secret generated+hashed) → optionally link to a `User` account for self-service.
- **Business rules**: BR-012 (audit on mutation).
- **Status**: Not implemented (module stub only).

### FR-007 — Affiliate Management & Approval
- **Purpose**: Affiliate self-registration/application, admin approval, status management.
- **Actor**: Affiliate (apply), Tenant Admin/Manager (approve/reject/suspend).
- **Main flow**: Affiliate applies → status=pending → admin reviews → approved/rejected → on approval, affiliate can generate tracking links (BR-007).
- **Failure**: Suspended affiliate's existing links stop accepting clicks.
- **Status**: Not implemented (module stub only).

### FR-008 — Offer Management
- **Purpose**: CRUD for offers (the advertiser's promotable product/action).
- **Actor**: Tenant Admin/Manager (create/edit), Advertiser (request only, per role-permission-matrix.md).
- **Fields involved**: title, landingUrl, fallbackUrl, revenue, payout, currency, conversionType, allowedCountries/Devices/TrafficSources, dailyCap, monthlyCap, requiresApproval, status.
- **Business rules**: BR-015 (revenue ≥ payout expectation).
- **Status**: Not implemented (module stub only).

### FR-009 — Tracking Link Generation
- **Purpose**: Generate a unique, opaque `trackingCode` per affiliate+offer(+campaign).
- **Actor**: Affiliate.
- **Main flow**: Affiliate selects an approved offer → system generates `trackingCode`, builds `trackingUrl` → affiliate copies link.
- **Business rules**: BR-007 (affiliate must be approved).
- **Status**: Not implemented (module stub only).

### FR-010 — Click Tracking & Redirect
- **Purpose**: The core tracking event — resolve a `trackingCode`, validate, log, redirect.
- **Actor**: End Visitor (via the affiliate's shared link); system-internal.
- **Preconditions**: `TrackingLink.status = active`, `Offer.status = active`, `Affiliate.status = approved`, `Tenant.status = active`.
- **Main flow**: `GET /go/{trackingCode}` → resolve link → validate targeting/caps → generate `clickId` → write `Click` row → append `clickId` to `Offer.landingUrl` → 302 redirect. Target: <100ms.
- **Alternative flow**: Cap exceeded / targeting mismatch → redirect to `Offer.fallbackUrl`, `Click.status = filtered`.
- **Failure**: Unknown `trackingCode`, inactive offer/affiliate/tenant → generic "unavailable" redirect, never a raw error page.
- **Business rules**: BR-007, BR-008.
- **Status**: Not implemented (module stub only) — **highest-priority MVP gap**.

### FR-011 — Postback / Conversion Recording
- **Purpose**: Record a conversion reported by an advertiser's server.
- **Actor**: External Advertiser Server.
- **Preconditions**: A prior `Click` exists for the referenced `clickId`, within its attribution window.
- **Main flow**: `POST /postback` with `{click_id, transaction_id, secret}` → verify secret → look up click → check `(tenantId, advertiserId, transactionId)` uniqueness → compute revenue/payout/profit server-side from `Offer` → write `Conversion` in a DB transaction → append `LedgerEntry` → queue fraud scoring/notifications → return `{success, status}`.
- **Alternative flow**: Duplicate `transactionId` → return a clean "duplicate ignored" response, not an error, not a second record.
- **Failure**: Invalid secret → 401/403 before any data read. Click not found / outside attribution window → 404.
- **Business rules**: BR-004, BR-005, BR-006, BR-011.
- **Status**: Not implemented (module stub only) — **second-highest-priority MVP gap**.

### FR-012 — Fraud Scoring
- **Purpose**: Compute a risk score for a click/conversion using internal rules.
- **Actor**: System-internal (triggered by FR-010/FR-011).
- **Main flow**: Evaluate signals (VPN +40, bot UA +30, IP burst +20, invalid country +50, duplicate conversion +100) → sum → classify (0–30 safe / 31–70 suspicious / 71–100 blocked) → write `FraudEvent`.
- **Business rules**: BR-010.
- **Status**: Not implemented (module stub only).

### FR-013 — Affiliate Ledger & Balance
- **Purpose**: Maintain an accurate, auditable record of what each affiliate has earned and is owed.
- **Actor**: System-internal (on conversion approval), Finance (view/adjust).
- **Status**: Not implemented. Target design introduces `LedgerEntry` (see ADR-006) rather than only mutating `Affiliate.balance`.

### FR-014 — Payout Workflow
- **Purpose**: Let an affiliate request payout of earned balance; let Finance approve and mark paid.
- **Actor**: Affiliate (request), Finance/Tenant Admin (approve/pay).
- **Main flow**: Affiliate requests → `Payout.status = requested` → Finance approves → `approved` → payment sent manually (MVP) → marked `paid`.
- **Business rules**: BR-009.
- **Status**: Not implemented (module stub only).

### FR-015 — Reporting Dashboard
- **Purpose**: Show clicks, conversions, revenue, payout, profit, conversion rate, EPC, broken down by date/offer/affiliate/advertiser/country/device.
- **Actor**: All tenant roles (scoped to what they're permitted to see per role-permission-matrix.md).
- **Status**: Not implemented (module stub only; `ReportSnapshot` model exists for future pre-aggregation).

### FR-016 — Role-Based Access Control Enforcement
- **Purpose**: Ensure every query/mutation is authorized by role and scoped by tenant.
- **Actor**: System-internal, applies to every other FR.
- **Status**: **Not implemented at all** — no `RolesGuard`, no tenant-context enforcement exists today. This is the single most critical gap; see [`../security/security-architecture.md`](../security/security-architecture.md).

---

### V1 Requirements (summary level)

- **FR-017** Subscription Plan & Stripe Billing — tenant subscribes to a plan, Stripe handles recurring charge, webhooks update `Subscription`/`Invoice`.
- **FR-018** Usage Metering Enforcement — `UsageCounter` increments per event, hard-limit blocks further usage (BR-014).
- **FR-019** Webhook Delivery to Advertisers — `WebhookEndpoint`/`WebhookDelivery` with retry + dead-letter.
- **FR-020** API Key Management — scoped keys (`ApiKeyScope`) for early integration partners.
- **FR-021** Notification Delivery — email + in-app, triggered by key events (conversion, payout status change, fraud flag).
- **FR-022** Audit Logging — every mutating action by an elevated role writes an `AuditLog` row (BR-012).

### V2+ Requirements (summary level)

- **FR-023** Third-party fraud signal integration (IPQualityScore, Fingerprint, MaxMind).
- **FR-024** Commission precedence rule engine (Global→Advertiser→Offer→Affiliate→Campaign).
- **FR-025** Automated payout (PayPal/Wise API).
- **FR-026** Platform-level tenant management dashboard (approve/suspend tenants, cross-tenant billing view).
- **FR-027** Smart Links — a single link that dynamically routes a visitor to different offers/landing pages based on geo/device/traffic-source, instead of requiring one `TrackingLink` per offer variant. Added after competitor review (trakaff.com) flagged this as a gap.
- **FR-028** Multi-Domain Tracking — a tenant can attach its own custom tracking domain(s), with auto-provisioned SSL and support for appending custom sub-parameters to the tracking URL.
- **FR-029** Two-Way API / Offer Sync — sync offers and affiliate data with external ad networks (Affise/Everflow-style integrations), beyond this platform's own API-key access.
- **FR-030** Pixel Tracking — a client-side tracking pixel as an alternative/complement to server-to-server postback, for advertisers who can't implement postbacks.
- **FR-031** Multi-Tier (MLM) Commission — support referral-based, multi-level commission structures beyond the current flat per-offer rate.
- **FR-032** Automated Invoicing — auto-generate and send an invoice document to the tenant on each billing event (subscription renewal, overage charge), not just a Stripe-hosted receipt.
- **FR-033** Additional Payment Gateways — Payoneer, RazorPay, and Webmoney as tenant/affiliate payment options alongside Stripe (subscriptions) and PayPal/Wise (payouts).
- **FR-034** Configurable Smart Alerts — let a tenant define its own threshold-based alert rules (e.g. "notify me if an affiliate's click-to-conversion ratio drops below X%"), beyond the fixed set of system events FR-021 already covers.
- **FR-035** Offline Conversion Import — let a tenant manually import/record conversions that happened outside the platform's own tracking (e.g. a phone sale), so payout/reporting still accounts for them.
- **FR-036** Campaign Automation — rule-based automated actions on a campaign (e.g. auto-pause on budget cap, auto-adjust payout on performance thresholds), beyond the manual CRUD `campaigns` module already planned.
- **FR-037** Lifetime/Recurring Commission — pay an affiliate on every future purchase (not just the first) made by a customer they referred, distinct from the current one-time-per-conversion payout model.

**Note**: FR-027 through FR-036 were added after a competitor feature review (trakaff.com, 2026-09-28) surfaced them as gaps versus this project's original plan. White-label (Phase 9), automated payout (FR-025), and multi-touch attribution (Open Questions #10/#11, Phase 9) were also found in that review but already existed in this plan — not re-added.
